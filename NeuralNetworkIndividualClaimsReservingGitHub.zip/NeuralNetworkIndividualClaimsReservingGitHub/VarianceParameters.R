###################################
### Variance Parameters         ###
### Author: Andrea Gabrielli    ###
### Date: 28.05.2020            ###
###################################


#####################################################
### Set working directory to source file location ###
#####################################################

### Session -> Set Working Directory -> To Source File Location


####################################################
### Load the required packages and source files  ###
####################################################

library(keras)
library(plyr)
source(file="./NeuralNetworkModels.R")


#########################
### Line of business  ###
#########################

LoB <- 1


######################
### Load the data  ###
######################

data <- read.table("./Data/data.txt", header=TRUE, sep=";")
data <- data[data$LoB==LoB,]
data$LoB <- as.factor(data$LoB)
data$cc <- as.factor(data$cc)
data$inj_part <- as.factor(data$inj_part)
str(data)


########################
### Data preparation ###
########################

### Features
data$RepDelnew <- pmin(2,data$RepDel)   ### cap reporting delay at 2
l0 <- ncol(data)
data$LoBx <- as.integer(as.numeric(data$LoB)-1)   ### LoB categorical (we will only use that as artificial embedding for dropout)
cc_transform <- cbind(as.integer(levels(data$cc)),0:(length(levels(data$cc))-1))
data$ccx <- cc_transform[data$cc,2]   ### cc categorical
data$AYx <- as.integer(data$AY-1994)   ### AY categorical
data$AQx <- as.integer(data$AQ-1)   ### AQ categorical
data$agex <- as.integer(levels(cut(data$age, c(14,20,25,30,35,40,45,50,55,60,65,70), right=TRUE, labels=c(0:10))))[cut(data$age, c(14,20,25,30,35,40,45,50,55,60,65,70), right=TRUE, labels=c(0:10))] ### age categorical in 5 years age buckets
inj_part_transform <- cbind(as.integer(levels(data$inj_part)),0:(length(levels(data$inj_part))-1))
data$inj_partx <- inj_part_transform[data$inj_part,2]   ### inj_part categorical
data$RepDelx <- as.integer(data$RepDelnew)   ### RepDelnew categorical

### Time known at the end of 2005 (time points for which we have the payment information at the end of year 2005)
l1 <- ncol(data)
data[,c("Time_Known00", "Time_Known01", "Time_Known02", "Time_Known03", "Time_Known04", "Time_Known05", "Time_Known06", "Time_Known07", "Time_Known08", "Time_Known09", "Time_Known10", "Time_Known11")] <- 0
for (i in 1:12){
  data[data$AY + data$RepDel <= 2006-i,l1+i] <- 1
}

### Past payment info (feature information about past payments, the information at time 11 is never used as a feature and thus neglected)
l2 <- ncol(data)
data[,c("Pay00Info", "Pay01Info", "Pay02Info", "Pay03Info", "Pay04Info", "Pay05Info", "Pay06Info", "Pay07Info", "Pay08Info", "Pay09Info", "Pay10Info")] <- as.integer(0)
for (i in 1:11){
  data[,l2+i][data[,l1+i]==1] <- as.integer(levels(cut(data[,8+i][data[,l1+i]==1], c(-Inf,-1,0,5000,20000,100000,Inf), right=TRUE, labels=c(1,0,2,3,4,5))))[cut(data[,8+i][data[,l1+i]==1], c(-Inf,-1,0,5000,20000,100000,Inf), right=TRUE, labels=c(1,0,2,3,4,5))]
}

### Payment indicator (response variable indicating whether we have a payment or not)
l3 <- ncol(data)
data[,c("PayInd00", "PayInd01", "PayInd02", "PayInd03", "PayInd04", "PayInd05", "PayInd06", "PayInd07", "PayInd08", "PayInd09", "PayInd10", "PayInd11")] <- as.integer(0)
for (i in 1:12){
  data[,l3+i][data[,l1+i]==1] <- as.integer(data[,8+i][data[,l1+i]==1]>0)
}

### Logarithmic payment (response variable indicating the log size of the payment if there is a payment)
l4 <- ncol(data)
data[,c("LogPay00", "LogPay01", "LogPay02", "LogPay03", "LogPay04", "LogPay05", "LogPay06", "LogPay07", "LogPay08", "LogPay09", "LogPay10", "LogPay11")] <- 0
for (i in 1:12){
  data[,l4+i][data[,l1+i]==1 & data[,8+i]>0] <- log(data[,8+i][data[,l1+i]==1 & data[,8+i]>0])
}

### Time points for which we would like to estimate the payment probability (during training these are equal to the time points known)
l5 <- ncol(data)
data[,c("Time_Predict_Indicator00", "Time_Predict_Indicator01", "Time_Predict_Indicator02", "Time_Predict_Indicator03", "Time_Predict_Indicator04", "Time_Predict_Indicator05", "Time_Predict_Indicator06", "Time_Predict_Indicator07", "Time_Predict_Indicator08", "Time_Predict_Indicator09", "Time_Predict_Indicator10", "Time_Predict_Indicator11")] <- 0
l6 <- ncol(data)
data[,(l5+1):l6] <- data[,(l1+1):(l1+12)]

### Time points for which we would like to estimate the payment size (during training these are equal to the time points where we have a payment)
data[,c("Time_Predict_Payment00", "Time_Predict_Payment01", "Time_Predict_Payment02", "Time_Predict_Payment03", "Time_Predict_Payment04", "Time_Predict_Payment05", "Time_Predict_Payment06", "Time_Predict_Payment07", "Time_Predict_Payment08", "Time_Predict_Payment09", "Time_Predict_Payment10", "Time_Predict_Payment11")] <- 0
l7 <- ncol(data)
data[,(l6+1):ncol(data)] <- data[,(l3+1):(l3+12)]


#######################################
### Training set and validation set ###
#######################################

set.seed(100)
choose_train <- sample(1:nrow(data), floor(0.5*nrow(data)), replace = FALSE)
data_train <- data[choose_train,]   ### training set
data_vali <- data[-choose_train,]   ### validation set


################
### Features ###
################

### Training set
features_train <- data.matrix(data_train[,c((l0+1):l1,(l1+2):l3,(l5+1):l7)])
features_train_input <- list(dropout = features_train[,1], cc = features_train[,2], AY = features_train[,3], AQ = features_train[,4], age = features_train[,5], inj_part = features_train[,6], RepDel = features_train[,7],
                             Time_Known01 = features_train[,8], Time_Known02 = features_train[,9], Time_Known03 = features_train[,10], Time_Known04 = features_train[,11], Time_Known05 = features_train[,12],
                             Time_Known06 = features_train[,13], Time_Known07 = features_train[,14], Time_Known08 = features_train[,15], Time_Known09 = features_train[,16], Time_Known10 = features_train[,17], Time_Known11 = features_train[,18],
                             Pay00Info = features_train[,19], Pay01Info = features_train[,20], Pay02Info = features_train[,21], Pay03Info = features_train[,22], Pay04Info = features_train[,23], Pay05Info = features_train[,24],
                             Pay06Info = features_train[,25], Pay07Info = features_train[,26], Pay08Info = features_train[,27], Pay09Info = features_train[,28], Pay10Info = features_train[,29],
                             Time_Predict_Indicator00 = features_train[,30], Time_Predict_Indicator01 = features_train[,31], Time_Predict_Indicator02 = features_train[,32], Time_Predict_Indicator03 = features_train[,33], Time_Predict_Indicator04 = features_train[,34], Time_Predict_Indicator05 = features_train[,35],
                             Time_Predict_Indicator06 = features_train[,36], Time_Predict_Indicator07 = features_train[,37], Time_Predict_Indicator08 = features_train[,38], Time_Predict_Indicator09 = features_train[,39], Time_Predict_Indicator10 = features_train[,40], Time_Predict_Indicator11 = features_train[,41],
                             Time_Predict_Payment00 = features_train[,42], Time_Predict_Payment01 = features_train[,43], Time_Predict_Payment02 = features_train[,44], Time_Predict_Payment03 = features_train[,45], Time_Predict_Payment04 = features_train[,46], Time_Predict_Payment05 = features_train[,47],
                             Time_Predict_Payment06 = features_train[,48], Time_Predict_Payment07 = features_train[,49], Time_Predict_Payment08 = features_train[,50], Time_Predict_Payment09 = features_train[,51], Time_Predict_Payment10 = features_train[,52], Time_Predict_Payment11 = features_train[,53])

### Validation set
features_vali <- data.matrix(data_vali[,c((l0+1):l1,(l1+2):l3,(l5+1):l7)])
features_vali_input <- list(dropout = features_vali[,1], cc = features_vali[,2], AY = features_vali[,3], AQ = features_vali[,4], age = features_vali[,5], inj_part = features_vali[,6], RepDel = features_vali[,7],
                            Time_Known01 = features_vali[,8], Time_Known02 = features_vali[,9], Time_Known03 = features_vali[,10], Time_Known04 = features_vali[,11], Time_Known05 = features_vali[,12],
                            Time_Known06 = features_vali[,13], Time_Known07 = features_vali[,14], Time_Known08 = features_vali[,15], Time_Known09 = features_vali[,16], Time_Known10 = features_vali[,17], Time_Known11 = features_vali[,18],
                            Pay00Info = features_vali[,19], Pay01Info = features_vali[,20], Pay02Info = features_vali[,21], Pay03Info = features_vali[,22], Pay04Info = features_vali[,23], Pay05Info = features_vali[,24],
                            Pay06Info = features_vali[,25], Pay07Info = features_vali[,26], Pay08Info = features_vali[,27], Pay09Info = features_vali[,28], Pay10Info = features_vali[,29],
                            Time_Predict_Indicator00 = features_vali[,30], Time_Predict_Indicator01 = features_vali[,31], Time_Predict_Indicator02 = features_vali[,32], Time_Predict_Indicator03 = features_vali[,33], Time_Predict_Indicator04 = features_vali[,34], Time_Predict_Indicator05 = features_vali[,35],
                            Time_Predict_Indicator06 = features_vali[,36], Time_Predict_Indicator07 = features_vali[,37], Time_Predict_Indicator08 = features_vali[,38], Time_Predict_Indicator09 = features_vali[,39], Time_Predict_Indicator10 = features_vali[,40], Time_Predict_Indicator11 = features_vali[,41],
                            Time_Predict_Payment00 = features_vali[,42], Time_Predict_Payment01 = features_vali[,43], Time_Predict_Payment02 = features_vali[,44], Time_Predict_Payment03 = features_vali[,45], Time_Predict_Payment04 = features_vali[,46], Time_Predict_Payment05 = features_vali[,47],
                            Time_Predict_Payment06 = features_vali[,48], Time_Predict_Payment07 = features_vali[,49], Time_Predict_Payment08 = features_vali[,50], Time_Predict_Payment09 = features_vali[,51], Time_Predict_Payment10 = features_vali[,52], Time_Predict_Payment11 = features_vali[,53])


#################
### Responses ###
#################

### Training set
responses_train <- data.matrix(data_train[,c((l3+1):l5)])
responses_train_input <- list(payment_indicator00_output = responses_train[,1], payment_mean00_output = responses_train[,13],
                              payment_indicator01_output = responses_train[,2], payment_mean01_output = responses_train[,14],
                              payment_indicator02_output = responses_train[,3], payment_mean02_output = responses_train[,15],
                              payment_indicator03_output = responses_train[,4], payment_mean03_output = responses_train[,16],
                              payment_indicator04_output = responses_train[,5], payment_mean04_output = responses_train[,17],
                              payment_indicator05_output = responses_train[,6], payment_mean05_output = responses_train[,18],
                              payment_indicator06_output = responses_train[,7], payment_mean06_output = responses_train[,19],
                              payment_indicator07_output = responses_train[,8], payment_mean07_output = responses_train[,20],
                              payment_indicator08_output = responses_train[,9], payment_mean08_output = responses_train[,21],
                              payment_indicator09_output = responses_train[,10], payment_mean09_output = responses_train[,22],
                              payment_indicator10_output = responses_train[,11], payment_mean10_output = responses_train[,23],
                              payment_indicator11_output = responses_train[,12], payment_mean11_output = responses_train[,24])

### Validation set
responses_vali <- data.matrix(data_vali[,c((l3+1):l5)])
responses_vali_input <- list(payment_indicator00_output = responses_vali[,1], payment_mean00_output = responses_vali[,13],
                             payment_indicator01_output = responses_vali[,2], payment_mean01_output = responses_vali[,14],
                             payment_indicator02_output = responses_vali[,3], payment_mean02_output = responses_vali[,15],
                             payment_indicator03_output = responses_vali[,4], payment_mean03_output = responses_vali[,16],
                             payment_indicator04_output = responses_vali[,5], payment_mean04_output = responses_vali[,17],
                             payment_indicator05_output = responses_vali[,6], payment_mean05_output = responses_vali[,18],
                             payment_indicator06_output = responses_vali[,7], payment_mean06_output = responses_vali[,19],
                             payment_indicator07_output = responses_vali[,8], payment_mean07_output = responses_vali[,20],
                             payment_indicator08_output = responses_vali[,9], payment_mean08_output = responses_vali[,21],
                             payment_indicator09_output = responses_vali[,10], payment_mean09_output = responses_vali[,22],
                             payment_indicator10_output = responses_vali[,11], payment_mean10_output = responses_vali[,23],
                             payment_indicator11_output = responses_vali[,12], payment_mean11_output = responses_vali[,24])


#######################
### Hyperparameters ###
#######################

### Random seed for Keras
set.seed(100)
seed1 <- sample(1:1000000, 1)

### Starting values of the neural network
starting_values <- array(NA, dim=c(12,2))
for (i in 1:12){
  starting_values[i,1] <- mean(data[data$AY+data$RepDel<=2006-i,8+i]>0)
  starting_values[i,2] <- mean(log(data[data$AY+data$RepDel<=2006-i,8+i][data[data$AY+data$RepDel<=2006-i,8+i]>0]))
}

### Dropout rates
dropout_rates <- 1/c(2:11)

### Weights
network_weights <- array(NA,dim=c(12,2))
for (i in 1:12){
  a <- as.numeric(data[data$AY+data$RepDel<=2006-i & data[,29+i]==1,8+i]>0)
  b <- nrow(data)-length(a)
  network_weights[i,1] <- -mean(c(a*log(mean(a))+(1-a)*log(1-mean(a)),rep(0,b)))
  a <- log(data[data$AY+data$RepDel<=2006-i & data[,29+i]==1,8+i][data[data$AY+data$RepDel<=2006-i & data[,29+i]==1,8+i]>0])
  b <- nrow(data)-length(a)
  network_weights[i,2] <- mean(c((a-mean(a))^2,rep(0,b)))
}
network_weights <- 1/network_weights

### Numbers of neurons
neurons <- c(40,30,10)

### Epochs
epochs <- as.numeric(read.table(paste("./Results/NumbersOfEpochs/SecondTrainingStep/LoB",LoB,"/Number_of_Epochs.txt", sep=""), header=TRUE, sep=";",row.names=1))

### Batchsize
batchsize <- 10000


#####################################################################
### Application of the neural network model (training/validation) ###
#####################################################################

k_clear_session()
model <- neural_network_fixed_embedding(seed1, neurons, dropout_rates, starting_values, network_weights)
a <- get_weights(model)
embeddings <- as.matrix(read.table(paste("./Results/Embeddings/LoB",LoB,"/Embedding_Weights_Indicator.txt", sep=""), header=TRUE, sep=";",row.names=1))
for (i in embeddings){
  a[[i]][1:length(a[[i]])] <- as.matrix(read.table(paste("./Results/Embeddings/LoB",LoB,"/Embedding_Weights_",i,".txt", sep=""), header=TRUE, sep=";",row.names=1))
}
set_weights(model,a)
fit = model %>% fit(x = features_train_input, y = responses_train_input, epochs = epochs, batch_size = batchsize, verbose = 0)
model %>% save_model_weights_hdf5(paste("./Results/VarianceParameters/LoB", LoB,"/weights_variance_parameters.hdf5",sep=""))


#########################################
### Calculate the variance parameters ###
#########################################

### Use the fitted neural network model
k_clear_session()
dropout_rates <- rep(0.00000000001,10)
model <- neural_network_fixed_embedding(seed1, neurons, dropout_rates, starting_values, network_weights)
load_model_weights_hdf5(model,paste("./Results/VarianceParameters/LoB", LoB,"/weights_variance_parameters.hdf5",sep=""))
prediction <- array(0,dim=c(nrow(data_vali),24))
prediction <- prediction + unlist(model %>% predict(features_vali_input))

### Determine sigma_squared
sigma_squared <- array(NA,12)
for (i in 0:11){
  a <- prediction[,2*(i+1)][data_vali[,9+i]>0 & data_vali[,30+i]==1]
  b <- log(data_vali[data_vali[,9+i]>0 & data_vali[,30+i]==1,9+i])
  sigma_squared[i+1] <- mean((a-b)^2)
}

### Store the results
write.table(sigma_squared, file=paste("./Results/VarianceParameters/LoB",LoB,"/sigma_squared.txt", sep=""), sep=";", row.names=TRUE, col.names=NA)
