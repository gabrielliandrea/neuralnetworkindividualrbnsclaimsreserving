###################################
### Variance Parameters         ###
### Author: Andrea Gabrielli    ###
### Date: 28.09.2020            ###
###################################


#####################################################
### Set working directory to source file location ###
#####################################################

### Session -> Set Working Directory -> To Source File Location


####################################################
### Load the required packages and source files  ###
####################################################

library(keras)
library(plyr)
source(file="./NeuralNetworkModels.R")


#########################
### Line of business  ###
#########################

LoB <- 1


######################
### Load the data  ###
######################

data <- read.table("./Data/data.txt", header=TRUE, sep=";")
data <- data[data$LoB==LoB,]
data$LoB <- as.factor(data$LoB)
data$cc <- as.factor(data$cc)
data$inj_part <- as.factor(data$inj_part)
str(data)


########################
### Data preparation ###
########################

### Features
data$RepDelnew <- pmin(2,data$RepDel)   ### cap reporting delay at 2
l0 <- ncol(data)
data$LoBx <- as.integer(as.numeric(data$LoB)-1)   ### LoB categorical (we will only use that as artificial embedding for dropout)
cc_transform <- cbind(as.integer(levels(data$cc)),0:(length(levels(data$cc))-1))
data$ccx <- cc_transform[data$cc,2]   ### cc categorical
data$AYx <- as.integer(data$AY-1994)   ### AY categorical
data$AQx <- as.integer(data$AQ-1)   ### AQ categorical
data$agex <- as.integer(levels(cut(data$age, c(14,20,25,30,35,40,45,50,55,60,65,70), right=TRUE, labels=c(0:10))))[cut(data$age, c(14,20,25,30,35,40,45,50,55,60,65,70), right=TRUE, labels=c(0:10))] ### age categorical in 5 years age buckets
inj_part_transform <- cbind(as.integer(levels(data$inj_part)),0:(length(levels(data$inj_part))-1))
data$inj_partx <- inj_part_transform[data$inj_part,2]   ### inj_part categorical
data$RepDelx <- as.integer(data$RepDelnew)   ### RepDelnew categorical

### Time known at the end of 2005 (time points for which we have the payment information at the end of year 2005)
l1 <- ncol(data)
data[,c("Time_Known00", "Time_Known01", "Time_Known02", "Time_Known03", "Time_Known04", "Time_Known05", "Time_Known06", "Time_Known07", "Time_Known08", "Time_Known09", "Time_Known10", "Time_Known11")] <- 0
for (i in 1:12){
  data[data$AY + data$RepDel <= 2006-i,l1+i] <- 1
}

### Past payment info (feature information about past payments, the information at time 11 is never used as a feature and thus neglected)
l2 <- ncol(data)
data[,c("Pay00Info", "Pay01Info", "Pay02Info", "Pay03Info", "Pay04Info", "Pay05Info", "Pay06Info", "Pay07Info", "Pay08Info", "Pay09Info", "Pay10Info")] <- as.integer(0)
for (i in 1:11){
  data[,l2+i][data[,l1+i]==1] <- as.integer(levels(cut(data[,8+i][data[,l1+i]==1], c(-Inf,-1,0,5000,20000,100000,Inf), right=TRUE, labels=c(1,0,2,3,4,5))))[cut(data[,8+i][data[,l1+i]==1], c(-Inf,-1,0,5000,20000,100000,Inf), right=TRUE, labels=c(1,0,2,3,4,5))]
}

### Payment indicator (response variable indicating whether we have a payment or not)
l3 <- ncol(data)
data[,c("PayInd00", "PayInd01", "PayInd02", "PayInd03", "PayInd04", "PayInd05", "PayInd06", "PayInd07", "PayInd08", "PayInd09", "PayInd10", "PayInd11")] <- as.integer(0)
for (i in 1:12){
  data[,l3+i][data[,l1+i]==1] <- as.integer(data[,8+i][data[,l1+i]==1]>0)
}

### Logarithmic payment (response variable indicating the log size of the payment if there is a payment)
l4 <- ncol(data)
data[,c("LogPay00", "LogPay01", "LogPay02", "LogPay03", "LogPay04", "LogPay05", "LogPay06", "LogPay07", "LogPay08", "LogPay09", "LogPay10", "LogPay11")] <- 0
for (i in 1:12){
  data[,l4+i][data[,l1+i]==1 & data[,8+i]>0] <- log(data[,8+i][data[,l1+i]==1 & data[,8+i]>0])
}

### Time points for which we would like to estimate the payment probability (during training these are equal to the time points known)
l5 <- ncol(data)
data[,c("Time_Predict_Indicator00", "Time_Predict_Indicator01", "Time_Predict_Indicator02", "Time_Predict_Indicator03", "Time_Predict_Indicator04", "Time_Predict_Indicator05", "Time_Predict_Indicator06", "Time_Predict_Indicator07", "Time_Predict_Indicator08", "Time_Predict_Indicator09", "Time_Predict_Indicator10", "Time_Predict_Indicator11")] <- 0
l6 <- ncol(data)
data[,(l5+1):l6] <- data[,(l1+1):(l1+12)]

### Time points for which we would like to estimate the payment size (during training these are equal to the time points where we have a payment)
data[,c("Time_Predict_Payment00", "Time_Predict_Payment01", "Time_Predict_Payment02", "Time_Predict_Payment03", "Time_Predict_Payment04", "Time_Predict_Payment05", "Time_Predict_Payment06", "Time_Predict_Payment07", "Time_Predict_Payment08", "Time_Predict_Payment09", "Time_Predict_Payment10", "Time_Predict_Payment11")] <- 0
l7 <- ncol(data)
data[,(l6+1):ncol(data)] <- data[,(l1+1):(l1+12)]


################
### Features ###
################

### Complete data set
features_all <- data.matrix(data[,c((l0+1):l1,(l1+2):l3,(l5+1):l7)])   ### l1+1 is Time_Known00, which is always equal to 1 and therefore omitted
features_all_input <- list(dropout = features_all[,1], cc = features_all[,2], AY = features_all[,3], AQ = features_all[,4], age = features_all[,5], inj_part = features_all[,6], RepDel = features_all[,7],
                           Time_Known01 = features_all[,8], Time_Known02 = features_all[,9], Time_Known03 = features_all[,10], Time_Known04 = features_all[,11], Time_Known05 = features_all[,12],
                           Time_Known06 = features_all[,13], Time_Known07 = features_all[,14], Time_Known08 = features_all[,15], Time_Known09 = features_all[,16], Time_Known10 = features_all[,17], Time_Known11 = features_all[,18],
                           Pay00Info = features_all[,19], Pay01Info = features_all[,20], Pay02Info = features_all[,21], Pay03Info = features_all[,22], Pay04Info = features_all[,23], Pay05Info = features_all[,24],
                           Pay06Info = features_all[,25], Pay07Info = features_all[,26], Pay08Info = features_all[,27], Pay09Info = features_all[,28], Pay10Info = features_all[,29],
                           Time_Predict_Indicator00 = features_all[,30], Time_Predict_Indicator01 = features_all[,31], Time_Predict_Indicator02 = features_all[,32], Time_Predict_Indicator03 = features_all[,33], Time_Predict_Indicator04 = features_all[,34], Time_Predict_Indicator05 = features_all[,35],
                           Time_Predict_Indicator06 = features_all[,36], Time_Predict_Indicator07 = features_all[,37], Time_Predict_Indicator08 = features_all[,38], Time_Predict_Indicator09 = features_all[,39], Time_Predict_Indicator10 = features_all[,40], Time_Predict_Indicator11 = features_all[,41],
                           Time_Predict_Payment00 = features_all[,42], Time_Predict_Payment01 = features_all[,43], Time_Predict_Payment02 = features_all[,44], Time_Predict_Payment03 = features_all[,45], Time_Predict_Payment04 = features_all[,46], Time_Predict_Payment05 = features_all[,47],
                           Time_Predict_Payment06 = features_all[,48], Time_Predict_Payment07 = features_all[,49], Time_Predict_Payment08 = features_all[,50], Time_Predict_Payment09 = features_all[,51], Time_Predict_Payment10 = features_all[,52], Time_Predict_Payment11 = features_all[,53])


################################################
### Apply the model on the complete data set ###
################################################

### Random seed for Keras
set.seed(100)
seed1 <- sample(1:1000000, 1)

### Starting values of the neural network
starting_values <- array(NA, dim=c(12,2))
for (i in 1:12){
  starting_values[i,1] <- mean(data[data$AY+data$RepDel<=2006-i,8+i]>0)
  starting_values[i,2] <- mean(log(data[data$AY+data$RepDel<=2006-i,8+i][data[data$AY+data$RepDel<=2006-i,8+i]>0]))
}

### Dropout rates
dropout_rates <- 1/c(2:11)

### Weights
network_weights <- array(NA,dim=c(12,2))
for (i in 1:12){
  a <- as.numeric(data[data$AY+data$RepDel<=2006-i & data[,29+i]==1,8+i]>0)
  b <- nrow(data)-length(a)
  network_weights[i,1] <- -mean(c(a*log(mean(a))+(1-a)*log(1-mean(a)),rep(0,b)))
  a <- log(data[data$AY+data$RepDel<=2006-i & data[,29+i]==1,8+i][data[data$AY+data$RepDel<=2006-i & data[,29+i]==1,8+i]>0])
  b <- nrow(data)-length(a)
  network_weights[i,2] <- mean(c((a-mean(a))^2,rep(0,b)))
}
network_weights <- 1/network_weights

### Numbers of neurons
neurons <- c(40,30,10)

### Epochs
epochs <- as.numeric(read.table(paste("./Results/NumbersOfEpochs/SecondTrainingStep/LoB",LoB,"/Number_of_Epochs.txt", sep=""), header=TRUE, sep=";",row.names=1))

### Use the fitted neural network models
k_clear_session()
dropout_rates <- rep(0.00000000001,10)
model <- neural_network_fixed_embedding(seed1, neurons, dropout_rates, starting_values, network_weights)
prediction_averaged <- array(0,dim=c(nrow(data),24))
considered_epochs <- c((epochs-2):(epochs+2))
for (e in considered_epochs){
  
  ### Current considered epoch
  print(e)
  
  ### Load the model weights
  e.count <- sprintf("%02d",e)
  load_model_weights_hdf5(model,paste("./Results/WeightsKerasModel/LoB", LoB,"/weights.",e.count,".hdf5",sep=""))
  
  ### Determine the predictions
  prediction <- model %>% predict(features_all_input)
  prediction_averaged <- prediction_averaged + unlist(prediction)
}

### Average the predictions
prediction_averaged <- prediction_averaged/length(considered_epochs)


##########################################
### Determine the variance parameters  ###
##########################################

### Determine sigma_squared
sigma_squared <- array(NA,12)
for (i in 1:12){
  sigma_squared[i] <- 2*log(sum(data[prediction_averaged[,2*(i-1)+1]>0,8+i])/sum(prediction_averaged[,2*(i-1)+1]*exp(prediction_averaged[,2*i])))
}
sigma_squared <- pmax(sigma_squared,0.000000001)

### Store the results
write.table(sigma_squared, file=paste("./Results/VarianceParameters/LoB",LoB,"/sigma_squared.txt", sep=""), sep=";", row.names=TRUE, col.names=NA)
