#######################################
### Neural Network Models           ###
### Author: Andrea Gabrielli        ###
### Date: 28.09.2020                ###
#######################################


##############################################################################################
### Definition of the function neural_network_train_embedding                              ###
### This function is used to train the neural network and to extract the embedding weights ###
##############################################################################################

### Define the function neural_network_train_embedding
### We have the following inputs:
### seed1 = set the seed for reproducibility
### neurons = number of neurons in the hidden layers of the neural network
### dropout_rates = dropout rates for the past payment information
### starting_values = starting values for the neural network parameters
### network_weights = weights of the individual parts of the loss function
neural_network_train_embedding <- function(seed1, neurons, dropout_rates, starting_values, network_weights){
  
  ### Seed
  
  use_session_with_seed(seed1)
  
  ### Dropout
  
  dropout_1_1 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_2 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_3 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_4 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_5 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_6 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_7 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_8 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_9 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_10 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_2_1 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_2 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_3 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_4 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_5 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_6 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_7 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_8 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_9 <- layer_dropout(rate = dropout_rates[2])
  dropout_3_1 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_2 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_3 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_4 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_5 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_6 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_7 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_8 <- layer_dropout(rate = dropout_rates[3])
  dropout_4_1 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_2 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_3 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_4 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_5 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_6 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_7 <- layer_dropout(rate = dropout_rates[4])
  dropout_5_1 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_2 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_3 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_4 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_5 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_6 <- layer_dropout(rate = dropout_rates[5])
  dropout_6_1 <- layer_dropout(rate = dropout_rates[6])
  dropout_6_2 <- layer_dropout(rate = dropout_rates[6])
  dropout_6_3 <- layer_dropout(rate = dropout_rates[6])
  dropout_6_4 <- layer_dropout(rate = dropout_rates[6])
  dropout_6_5 <- layer_dropout(rate = dropout_rates[6])
  dropout_7_1 <- layer_dropout(rate = dropout_rates[7])
  dropout_7_2 <- layer_dropout(rate = dropout_rates[7])
  dropout_7_3 <- layer_dropout(rate = dropout_rates[7])
  dropout_7_4 <- layer_dropout(rate = dropout_rates[7])
  dropout_8_1 <- layer_dropout(rate = dropout_rates[8])
  dropout_8_2 <- layer_dropout(rate = dropout_rates[8])
  dropout_8_3 <- layer_dropout(rate = dropout_rates[8])
  dropout_9_1 <- layer_dropout(rate = dropout_rates[9])
  dropout_9_2 <- layer_dropout(rate = dropout_rates[9])
  dropout_10_1 <- layer_dropout(rate = dropout_rates[10])
  
  ### Inputs
  
  dropout <- layer_input(shape = c(1), dtype = 'int32', name = 'dropout')
  
  cc <- layer_input(shape = c(1), dtype = 'int32', name = 'cc')
  
  AY <- layer_input(shape = c(1), dtype = 'int32', name = 'AY')
  
  AQ <- layer_input(shape = c(1), dtype = 'int32', name = 'AQ')
  
  age <- layer_input(shape = c(1), dtype = 'int32', name = 'age')
  
  inj_part <- layer_input(shape = c(1), dtype = 'int32', name = 'inj_part')
  
  RepDel <- layer_input(shape = c(1), dtype = 'int32', name = 'RepDel')
  
  Time_Known01 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known01')
  
  Time_Known02 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known02')
  
  Time_Known03 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known03')
  
  Time_Known04 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known04')
  
  Time_Known05 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known05')
  
  Time_Known06 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known06')
  
  Time_Known07 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known07')
  
  Time_Known08 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known08')
  
  Time_Known09 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known09')
  
  Time_Known10 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known10')
  
  Time_Known11 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known11')
  
  Pay00Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay00Info')
  
  Pay01Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay01Info')
  
  Pay02Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay02Info')
  
  Pay03Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay03Info')
  
  Pay04Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay04Info')
  
  Pay05Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay05Info')
  
  Pay06Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay06Info')
  
  Pay07Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay07Info')
  
  Pay08Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay08Info')
  
  Pay09Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay09Info')
  
  Pay10Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay10Info')
  
  Time_Predict_Indicator00 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator00')
  
  Time_Predict_Indicator01 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator01')
  
  Time_Predict_Indicator02 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator02')
  
  Time_Predict_Indicator03 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator03')
  
  Time_Predict_Indicator04 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator04')
  
  Time_Predict_Indicator05 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator05')
  
  Time_Predict_Indicator06 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator06')
  
  Time_Predict_Indicator07 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator07')
  
  Time_Predict_Indicator08 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator08')
  
  Time_Predict_Indicator09 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator09')
  
  Time_Predict_Indicator10 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator10')
  
  Time_Predict_Indicator11 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator11')
  
  Time_Predict_Payment00 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment00')
  
  Time_Predict_Payment01 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment01')
  
  Time_Predict_Payment02 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment02')
  
  Time_Predict_Payment03 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment03')
  
  Time_Predict_Payment04 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment04')
  
  Time_Predict_Payment05 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment05')
  
  Time_Predict_Payment06 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment06')
  
  Time_Predict_Payment07 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment07')
  
  Time_Predict_Payment08 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment08')
  
  Time_Predict_Payment09 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment09')
  
  Time_Predict_Payment10 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment10')
  
  Time_Predict_Payment11 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment11')
  
  ### Embeddings
  
  dropout_embed <- dropout %>% 
    layer_embedding(input_dim = 1, output_dim = 1, trainable=FALSE, input_length = 1,
                    weights=list(matrix(c(1)))) %>%
    layer_flatten
  
  cc_embed_input <- cc %>% 
    layer_embedding(input_dim = 51, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  cc_embed_output <- cc %>% 
    layer_embedding(input_dim = 51, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  AY_embed_input <- AY %>% 
    layer_embedding(input_dim = 12, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  AY_embed_output <- AY %>% 
    layer_embedding(input_dim = 12, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  AQ_embed_input <- AQ %>% 
    layer_embedding(input_dim = 4, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  AQ_embed_output <- AQ %>% 
    layer_embedding(input_dim = 4, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  age_embed_input <- age %>% 
    layer_embedding(input_dim = 12, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  age_embed_output <- age %>% 
    layer_embedding(input_dim = 12, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  inj_part_embed_input <- inj_part %>% 
    layer_embedding(input_dim = 46, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  inj_part_embed_output <- inj_part %>% 
    layer_embedding(input_dim = 46, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  RepDel_embed_input <- RepDel %>% 
    layer_embedding(input_dim = 3, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  RepDel_embed_output <- RepDel %>% 
    layer_embedding(input_dim = 3, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay00Info_embed_input <- Pay00Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay00Info_embed_output <- Pay00Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay01Info_embed_input <- Pay01Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay01Info_embed_output <- Pay01Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay02Info_embed_input <- Pay02Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay02Info_embed_output <- Pay02Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay03Info_embed_input <- Pay03Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay03Info_embed_output <- Pay03Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay04Info_embed_input <- Pay04Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay04Info_embed_output <- Pay04Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay05Info_embed_input <- Pay05Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay05Info_embed_output <- Pay05Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay06Info_embed_input <- Pay06Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay06Info_embed_output <- Pay06Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay07Info_embed_input <- Pay07Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay07Info_embed_output <- Pay07Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay08Info_embed_input <- Pay08Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay08Info_embed_output <- Pay08Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay09Info_embed_input <- Pay09Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay09Info_embed_output <- Pay09Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay10Info_embed_input <- Pay10Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  Pay10Info_embed_output <- Pay10Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1) %>%
    layer_flatten
  
  ### Time 00 - Time 11
  
  features_input <- list(cc_embed_input, AQ_embed_input, age_embed_input, inj_part_embed_input, RepDel_embed_input) %>%
    layer_concatenate
  
  AY_embed_input_NN <- AY_embed_input %>%
    layer_dense(units = neurons[1], activation='linear')
  
  features_output <- list(cc_embed_output, AQ_embed_output, age_embed_output, inj_part_embed_output, RepDel_embed_output) %>%
    layer_concatenate
  
  AY_output_indicator <- AY_embed_output %>%
    layer_dense(units = 1, activation='linear', name="AY_output_indicator",
                weights = list(array(0,dim=c(1,1)),array(0,dim=c(1))))
  
  AY_output_mean <- AY_embed_output %>%
    layer_dense(units = 1, activation='linear', name="AY_output_mean",
                weights = list(array(0,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 00
  
  hidden_0_pre <- features_input %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_0 <- list(hidden_0_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator00_pre <- hidden_0 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator00_pre2 <- list(payment_indicator00_pre, features_output) %>%
    layer_concatenate(name = "pay_ind00") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+5),dim=c(neurons[3]+5,1)),array(log(starting_values[1,1]/(1-starting_values[1,1])),dim=c(1))))
  
  payment_indicator00 <- list(payment_indicator00_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean00_pre <- hidden_0 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean00_pre2 <- list(payment_mean00_pre, features_output) %>%
    layer_concatenate(name = "pay_mean00") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+5),dim=c(neurons[3]+5,1)),array(starting_values[1,2],dim=c(1))))
  
  payment_mean00 <- list(payment_mean00_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 01
  
  hidden_1_pre <- list(features_input, Pay00Info_embed_input) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_1 <- list(hidden_1_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator01_pre <- hidden_1 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator01_pre2 <- list(payment_indicator01_pre, features_output, Pay00Info_embed_output) %>%
    layer_concatenate(name = "pay_ind01") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+6),dim=c(neurons[3]+6,1)),array(log(starting_values[2,1]/(1-starting_values[2,1])),dim=c(1))))
  
  payment_indicator01 <- list(payment_indicator01_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean01_pre <- hidden_1 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean01_pre2 <- list(payment_mean01_pre, features_output, Pay00Info_embed_output) %>%
    layer_concatenate(name = "pay_mean01") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+6),dim=c(neurons[3]+6,1)),array(starting_values[2,2],dim=c(1))))
  
  payment_mean01 <- list(payment_mean01_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 02
  
  dropout_1_10_applied <- dropout_embed %>%
    dropout_1_10(training = TRUE)
  
  Pay01Info_embed_input_dropout_02 <- list(Pay01Info_embed_input, dropout_1_10_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_02 <- list(Pay01Info_embed_output, dropout_1_10_applied, Time_Known01) %>%
    layer_multiply()
  
  hidden_2_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_02) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_2 <- list(hidden_2_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator02_pre <- hidden_2 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator02_pre2 <- list(payment_indicator02_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_02) %>%
    layer_concatenate(name = "pay_ind02") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+7),dim=c(neurons[3]+7,1)),array(log(starting_values[3,1]/(1-starting_values[3,1])),dim=c(1))))
  
  payment_indicator02 <- list(payment_indicator02_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean02_pre <- hidden_2 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean02_pre2 <- list(payment_mean02_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_02) %>%
    layer_concatenate(name = "pay_mean02") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+7),dim=c(neurons[3]+7,1)),array(starting_values[3,2],dim=c(1))))
  
  payment_mean02 <- list(payment_mean02_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 03
  
  dropout_1_9_applied <- dropout_embed %>%
    dropout_1_9(training = TRUE)
  
  dropout_2_9_applied <- dropout_embed %>%
    dropout_2_9(training = TRUE)
  
  Pay01Info_embed_input_dropout_03 <- list(Pay01Info_embed_input, dropout_2_9_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_03 <- list(Pay01Info_embed_output, dropout_2_9_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_03 <- list(Pay02Info_embed_input, dropout_2_9_applied, dropout_1_9_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_03 <- list(Pay02Info_embed_output, dropout_2_9_applied, dropout_1_9_applied, Time_Known02) %>%
    layer_multiply()
  
  hidden_3_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_03, Pay02Info_embed_input_dropout_03) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_3 <- list(hidden_3_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator03_pre <- hidden_3 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator03_pre2 <- list(payment_indicator03_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_03, Pay02Info_embed_output_dropout_03) %>%
    layer_concatenate(name = "pay_ind03") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+8),dim=c(neurons[3]+8,1)),array(log(starting_values[4,1]/(1-starting_values[4,1])),dim=c(1))))
  
  payment_indicator03 <- list(payment_indicator03_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean03_pre <- hidden_3 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean03_pre2 <- list(payment_mean03_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_03, Pay02Info_embed_output_dropout_03) %>%
    layer_concatenate(name = "pay_mean03") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+8),dim=c(neurons[3]+8,1)),array(starting_values[4,2],dim=c(1))))
  
  payment_mean03 <- list(payment_mean03_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 04
  
  dropout_1_8_applied <- dropout_embed %>%
    dropout_1_8(training = TRUE)
  
  dropout_2_8_applied <- dropout_embed %>%
    dropout_2_8(training = TRUE)
  
  dropout_3_8_applied <- dropout_embed %>%
    dropout_3_8(training = TRUE)
  
  Pay01Info_embed_input_dropout_04 <- list(Pay01Info_embed_input, dropout_3_8_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_04 <- list(Pay01Info_embed_output, dropout_3_8_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_04 <- list(Pay02Info_embed_input, dropout_3_8_applied, dropout_2_8_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_04 <- list(Pay02Info_embed_output, dropout_3_8_applied, dropout_2_8_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_04 <- list(Pay03Info_embed_input, dropout_3_8_applied, dropout_2_8_applied, dropout_1_8_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_04 <- list(Pay03Info_embed_output, dropout_3_8_applied, dropout_2_8_applied, dropout_1_8_applied, Time_Known03) %>%
    layer_multiply()
  
  hidden_4_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_04, Pay02Info_embed_input_dropout_04, Pay03Info_embed_input_dropout_04) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_4 <- list(hidden_4_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator04_pre <- hidden_4 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator04_pre2 <- list(payment_indicator04_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_04, Pay02Info_embed_output_dropout_04, Pay03Info_embed_output_dropout_04) %>%
    layer_concatenate(name = "pay_ind04") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+9),dim=c(neurons[3]+9,1)),array(log(starting_values[5,1]/(1-starting_values[5,1])),dim=c(1))))
  
  payment_indicator04 <- list(payment_indicator04_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean04_pre <- hidden_4 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean04_pre2 <- list(payment_mean04_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_04, Pay02Info_embed_output_dropout_04, Pay03Info_embed_output_dropout_04) %>%
    layer_concatenate(name = "pay_mean04") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+9),dim=c(neurons[3]+9,1)),array(starting_values[5,2],dim=c(1))))
  
  payment_mean04 <- list(payment_mean04_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 05
  
  dropout_1_7_applied <- dropout_embed %>%
    dropout_1_7(training = TRUE)
  
  dropout_2_7_applied <- dropout_embed %>%
    dropout_2_7(training = TRUE)
  
  dropout_3_7_applied <- dropout_embed %>%
    dropout_3_7(training = TRUE)
  
  dropout_4_7_applied <- dropout_embed %>%
    dropout_4_7(training = TRUE)
  
  Pay01Info_embed_input_dropout_05 <- list(Pay01Info_embed_input, dropout_4_7_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_05 <- list(Pay01Info_embed_output, dropout_4_7_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_05 <- list(Pay02Info_embed_input, dropout_4_7_applied, dropout_3_7_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_05 <- list(Pay02Info_embed_output, dropout_4_7_applied, dropout_3_7_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_05 <- list(Pay03Info_embed_input, dropout_4_7_applied, dropout_3_7_applied, dropout_2_7_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_05 <- list(Pay03Info_embed_output, dropout_4_7_applied, dropout_3_7_applied, dropout_2_7_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_05 <- list(Pay04Info_embed_input, dropout_4_7_applied, dropout_3_7_applied, dropout_2_7_applied, dropout_1_7_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_05 <- list(Pay04Info_embed_output, dropout_4_7_applied, dropout_3_7_applied, dropout_2_7_applied, dropout_1_7_applied, Time_Known04) %>%
    layer_multiply()
  
  hidden_5_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_05, Pay02Info_embed_input_dropout_05, Pay03Info_embed_input_dropout_05, Pay04Info_embed_input_dropout_05) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_5 <- list(hidden_5_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator05_pre <- hidden_5 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator05_pre2 <- list(payment_indicator05_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_05, Pay02Info_embed_output_dropout_05, Pay03Info_embed_output_dropout_05, Pay04Info_embed_output_dropout_05) %>%
    layer_concatenate(name = "pay_ind05") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+10),dim=c(neurons[3]+10,1)),array(log(starting_values[6,1]/(1-starting_values[6,1])),dim=c(1))))
  
  payment_indicator05 <- list(payment_indicator05_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean05_pre <- hidden_5 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean05_pre2 <- list(payment_mean05_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_05, Pay02Info_embed_output_dropout_05, Pay03Info_embed_output_dropout_05, Pay04Info_embed_output_dropout_05) %>%
    layer_concatenate(name = "pay_mean05") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+10),dim=c(neurons[3]+10,1)),array(starting_values[6,2],dim=c(1))))
  
  payment_mean05 <- list(payment_mean05_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 06
  
  dropout_1_6_applied <- dropout_embed %>%
    dropout_1_6(training = TRUE)
  
  dropout_2_6_applied <- dropout_embed %>%
    dropout_2_6(training = TRUE)
  
  dropout_3_6_applied <- dropout_embed %>%
    dropout_3_6(training = TRUE)
  
  dropout_4_6_applied <- dropout_embed %>%
    dropout_4_6(training = TRUE)
  
  dropout_5_6_applied <- dropout_embed %>%
    dropout_5_6(training = TRUE)
  
  Pay01Info_embed_input_dropout_06 <- list(Pay01Info_embed_input, dropout_5_6_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_06 <- list(Pay01Info_embed_output, dropout_5_6_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_06 <- list(Pay02Info_embed_input, dropout_5_6_applied, dropout_4_6_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_06 <- list(Pay02Info_embed_output, dropout_5_6_applied, dropout_4_6_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_06 <- list(Pay03Info_embed_input, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_06 <- list(Pay03Info_embed_output, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_06 <- list(Pay04Info_embed_input, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, dropout_2_6_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_06 <- list(Pay04Info_embed_output, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, dropout_2_6_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_06 <- list(Pay05Info_embed_input, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, dropout_2_6_applied, dropout_1_6_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_06 <- list(Pay05Info_embed_output, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, dropout_2_6_applied, dropout_1_6_applied, Time_Known05) %>%
    layer_multiply()
  
  hidden_6_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_06, Pay02Info_embed_input_dropout_06, Pay03Info_embed_input_dropout_06, Pay04Info_embed_input_dropout_06, Pay05Info_embed_input_dropout_06) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_6 <- list(hidden_6_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator06_pre <- hidden_6 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator06_pre2 <- list(payment_indicator06_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_06, Pay02Info_embed_output_dropout_06, Pay03Info_embed_output_dropout_06, Pay04Info_embed_output_dropout_06, Pay05Info_embed_output_dropout_06) %>%
    layer_concatenate(name = "pay_ind06") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+11),dim=c(neurons[3]+11,1)),array(log(starting_values[7,1]/(1-starting_values[7,1])),dim=c(1))))
  
  payment_indicator06 <- list(payment_indicator06_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean06_pre <- hidden_6 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean06_pre2 <- list(payment_mean06_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_06, Pay02Info_embed_output_dropout_06, Pay03Info_embed_output_dropout_06, Pay04Info_embed_output_dropout_06, Pay05Info_embed_output_dropout_06) %>%
    layer_concatenate(name = "pay_mean06") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+11),dim=c(neurons[3]+11,1)),array(starting_values[7,2],dim=c(1))))
  
  payment_mean06 <- list(payment_mean06_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 07
  
  dropout_1_5_applied <- dropout_embed %>%
    dropout_1_5(training = TRUE)
  
  dropout_2_5_applied <- dropout_embed %>%
    dropout_2_5(training = TRUE)
  
  dropout_3_5_applied <- dropout_embed %>%
    dropout_3_5(training = TRUE)
  
  dropout_4_5_applied <- dropout_embed %>%
    dropout_4_5(training = TRUE)
  
  dropout_5_5_applied <- dropout_embed %>%
    dropout_5_5(training = TRUE)
  
  dropout_6_5_applied <- dropout_embed %>%
    dropout_6_5(training = TRUE)
  
  Pay01Info_embed_input_dropout_07 <- list(Pay01Info_embed_input, dropout_6_5_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_07 <- list(Pay01Info_embed_output, dropout_6_5_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_07 <- list(Pay02Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_07 <- list(Pay02Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_07 <- list(Pay03Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_07 <- list(Pay03Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_07 <- list(Pay04Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_07 <- list(Pay04Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_07 <- list(Pay05Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, dropout_2_5_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_07 <- list(Pay05Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, dropout_2_5_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_07 <- list(Pay06Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, dropout_2_5_applied, dropout_1_5_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_07 <- list(Pay06Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, dropout_2_5_applied, dropout_1_5_applied, Time_Known06) %>%
    layer_multiply()
  
  hidden_7_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_07, Pay02Info_embed_input_dropout_07, Pay03Info_embed_input_dropout_07, Pay04Info_embed_input_dropout_07, Pay05Info_embed_input_dropout_07, Pay06Info_embed_input_dropout_07) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_7 <- list(hidden_7_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator07_pre <- hidden_7 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator07_pre2 <- list(payment_indicator07_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_07, Pay02Info_embed_output_dropout_07, Pay03Info_embed_output_dropout_07, Pay04Info_embed_output_dropout_07, Pay05Info_embed_output_dropout_07, Pay06Info_embed_output_dropout_07) %>%
    layer_concatenate(name = "pay_ind07") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+12),dim=c(neurons[3]+12,1)),array(log(starting_values[8,1]/(1-starting_values[8,1])),dim=c(1))))
  
  payment_indicator07 <- list(payment_indicator07_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean07_pre <- hidden_7 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean07_pre2 <- list(payment_mean07_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_07, Pay02Info_embed_output_dropout_07, Pay03Info_embed_output_dropout_07, Pay04Info_embed_output_dropout_07, Pay05Info_embed_output_dropout_07, Pay06Info_embed_output_dropout_07) %>%
    layer_concatenate(name = "pay_mean07") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+12),dim=c(neurons[3]+12,1)),array(starting_values[8,2],dim=c(1))))
  
  payment_mean07 <- list(payment_mean07_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 08
  
  dropout_1_4_applied <- dropout_embed %>%
    dropout_1_4(training = TRUE)
  
  dropout_2_4_applied <- dropout_embed %>%
    dropout_2_4(training = TRUE)
  
  dropout_3_4_applied <- dropout_embed %>%
    dropout_3_4(training = TRUE)
  
  dropout_4_4_applied <- dropout_embed %>%
    dropout_4_4(training = TRUE)
  
  dropout_5_4_applied <- dropout_embed %>%
    dropout_5_4(training = TRUE)
  
  dropout_6_4_applied <- dropout_embed %>%
    dropout_6_4(training = TRUE)
  
  dropout_7_4_applied <- dropout_embed %>%
    dropout_7_4(training = TRUE)
  
  Pay01Info_embed_input_dropout_08 <- list(Pay01Info_embed_input, dropout_7_4_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_08 <- list(Pay01Info_embed_output, dropout_7_4_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_08 <- list(Pay02Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_08 <- list(Pay02Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_08 <- list(Pay03Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_08 <- list(Pay03Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_08 <- list(Pay04Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_08 <- list(Pay04Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_08 <- list(Pay05Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_08 <- list(Pay05Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_08 <- list(Pay06Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, dropout_2_4_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_08 <- list(Pay06Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, dropout_2_4_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay07Info_embed_input_dropout_08 <- list(Pay07Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, dropout_2_4_applied, dropout_1_4_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay07Info_embed_output_dropout_08 <- list(Pay07Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, dropout_2_4_applied, dropout_1_4_applied, Time_Known07) %>%
    layer_multiply()
  
  hidden_8_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_08, Pay02Info_embed_input_dropout_08, Pay03Info_embed_input_dropout_08, Pay04Info_embed_input_dropout_08, Pay05Info_embed_input_dropout_08, Pay06Info_embed_input_dropout_08, Pay07Info_embed_input_dropout_08) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_8 <- list(hidden_8_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator08_pre <- hidden_8 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator08_pre2 <- list(payment_indicator08_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_08, Pay02Info_embed_output_dropout_08, Pay03Info_embed_output_dropout_08, Pay04Info_embed_output_dropout_08, Pay05Info_embed_output_dropout_08, Pay06Info_embed_output_dropout_08, Pay07Info_embed_output_dropout_08) %>%
    layer_concatenate(name = "pay_ind08") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+13),dim=c(neurons[3]+13,1)),array(log(starting_values[9,1]/(1-starting_values[9,1])),dim=c(1))))
  
  payment_indicator08 <- list(payment_indicator08_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean08_pre <- hidden_8 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean08_pre2 <- list(payment_mean08_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_08, Pay02Info_embed_output_dropout_08, Pay03Info_embed_output_dropout_08, Pay04Info_embed_output_dropout_08, Pay05Info_embed_output_dropout_08, Pay06Info_embed_output_dropout_08, Pay07Info_embed_output_dropout_08) %>%
    layer_concatenate(name = "pay_mean08") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+13),dim=c(neurons[3]+13,1)),array(starting_values[9,2],dim=c(1))))
  
  payment_mean08 <- list(payment_mean08_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 09
  
  dropout_1_3_applied <- dropout_embed %>%
    dropout_1_3(training = TRUE)
  
  dropout_2_3_applied <- dropout_embed %>%
    dropout_2_3(training = TRUE)
  
  dropout_3_3_applied <- dropout_embed %>%
    dropout_3_3(training = TRUE)
  
  dropout_4_3_applied <- dropout_embed %>%
    dropout_4_3(training = TRUE)
  
  dropout_5_3_applied <- dropout_embed %>%
    dropout_5_3(training = TRUE)
  
  dropout_6_3_applied <- dropout_embed %>%
    dropout_6_3(training = TRUE)
  
  dropout_7_3_applied <- dropout_embed %>%
    dropout_7_3(training = TRUE)
  
  dropout_8_3_applied <- dropout_embed %>%
    dropout_8_3(training = TRUE)
  
  Pay01Info_embed_input_dropout_09 <- list(Pay01Info_embed_input, dropout_8_3_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_09 <- list(Pay01Info_embed_output, dropout_8_3_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_09 <- list(Pay02Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_09 <- list(Pay02Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_09 <- list(Pay03Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_09 <- list(Pay03Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_09 <- list(Pay04Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_09 <- list(Pay04Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_09 <- list(Pay05Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_09 <- list(Pay05Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_09 <- list(Pay06Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_09 <- list(Pay06Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay07Info_embed_input_dropout_09 <- list(Pay07Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, dropout_2_3_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay07Info_embed_output_dropout_09 <- list(Pay07Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, dropout_2_3_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay08Info_embed_input_dropout_09 <- list(Pay08Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, dropout_2_3_applied, dropout_1_3_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay08Info_embed_output_dropout_09 <- list(Pay08Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, dropout_2_3_applied, dropout_1_3_applied, Time_Known08) %>%
    layer_multiply()
  
  hidden_9_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_09, Pay02Info_embed_input_dropout_09, Pay03Info_embed_input_dropout_09, Pay04Info_embed_input_dropout_09, Pay05Info_embed_input_dropout_09, Pay06Info_embed_input_dropout_09, Pay07Info_embed_input_dropout_09, Pay08Info_embed_input_dropout_09) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_9 <- list(hidden_9_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator09_pre <- hidden_9 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator09_pre2 <- list(payment_indicator09_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_09, Pay02Info_embed_output_dropout_09, Pay03Info_embed_output_dropout_09, Pay04Info_embed_output_dropout_09, Pay05Info_embed_output_dropout_09, Pay06Info_embed_output_dropout_09, Pay07Info_embed_output_dropout_09, Pay08Info_embed_output_dropout_09) %>%
    layer_concatenate(name = "pay_ind09") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+14),dim=c(neurons[3]+14,1)),array(log(starting_values[10,1]/(1-starting_values[10,1])),dim=c(1))))
  
  payment_indicator09 <- list(payment_indicator09_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean09_pre <- hidden_9 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean09_pre2 <- list(payment_mean09_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_09, Pay02Info_embed_output_dropout_09, Pay03Info_embed_output_dropout_09, Pay04Info_embed_output_dropout_09, Pay05Info_embed_output_dropout_09, Pay06Info_embed_output_dropout_09, Pay07Info_embed_output_dropout_09, Pay08Info_embed_output_dropout_09) %>%
    layer_concatenate(name = "pay_mean09") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+14),dim=c(neurons[3]+14,1)),array(starting_values[10,2],dim=c(1))))
  
  payment_mean09 <- list(payment_mean09_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 10
  
  dropout_1_2_applied <- dropout_embed %>%
    dropout_1_2(training = TRUE)
  
  dropout_2_2_applied <- dropout_embed %>%
    dropout_2_2(training = TRUE)
  
  dropout_3_2_applied <- dropout_embed %>%
    dropout_3_2(training = TRUE)
  
  dropout_4_2_applied <- dropout_embed %>%
    dropout_4_2(training = TRUE)
  
  dropout_5_2_applied <- dropout_embed %>%
    dropout_5_2(training = TRUE)
  
  dropout_6_2_applied <- dropout_embed %>%
    dropout_6_2(training = TRUE)
  
  dropout_7_2_applied <- dropout_embed %>%
    dropout_7_2(training = TRUE)
  
  dropout_8_2_applied <- dropout_embed %>%
    dropout_8_2(training = TRUE)
  
  dropout_9_2_applied <- dropout_embed %>%
    dropout_9_2(training = TRUE)
  
  Pay01Info_embed_input_dropout_10 <- list(Pay01Info_embed_input, dropout_9_2_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_10 <- list(Pay01Info_embed_output, dropout_9_2_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_10 <- list(Pay02Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_10 <- list(Pay02Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_10 <- list(Pay03Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_10 <- list(Pay03Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_10 <- list(Pay04Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_10 <- list(Pay04Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_10 <- list(Pay05Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_10 <- list(Pay05Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_10 <- list(Pay06Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_10 <- list(Pay06Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay07Info_embed_input_dropout_10 <- list(Pay07Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay07Info_embed_output_dropout_10 <- list(Pay07Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay08Info_embed_input_dropout_10 <- list(Pay08Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, dropout_2_2_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay08Info_embed_output_dropout_10 <- list(Pay08Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, dropout_2_2_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay09Info_embed_input_dropout_10 <- list(Pay09Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, dropout_2_2_applied, dropout_1_2_applied, Time_Known09) %>%
    layer_multiply()
  
  Pay09Info_embed_output_dropout_10 <- list(Pay09Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, dropout_2_2_applied, dropout_1_2_applied, Time_Known09) %>%
    layer_multiply()
  
  hidden_10_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_10, Pay02Info_embed_input_dropout_10, Pay03Info_embed_input_dropout_10, Pay04Info_embed_input_dropout_10, Pay05Info_embed_input_dropout_10, Pay06Info_embed_input_dropout_10, Pay07Info_embed_input_dropout_10, Pay08Info_embed_input_dropout_10, Pay09Info_embed_input_dropout_10) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_10 <- list(hidden_10_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator10_pre <- hidden_10 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator10_pre2 <- list(payment_indicator10_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_10, Pay02Info_embed_output_dropout_10, Pay03Info_embed_output_dropout_10, Pay04Info_embed_output_dropout_10, Pay05Info_embed_output_dropout_10, Pay06Info_embed_output_dropout_10, Pay07Info_embed_output_dropout_10, Pay08Info_embed_output_dropout_10, Pay09Info_embed_output_dropout_10) %>%
    layer_concatenate(name = "pay_ind10") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+15),dim=c(neurons[3]+15,1)),array(log(starting_values[11,1]/(1-starting_values[11,1])),dim=c(1))))
  
  payment_indicator10 <- list(payment_indicator10_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean10_pre <- hidden_10 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean10_pre2 <- list(payment_mean10_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_10, Pay02Info_embed_output_dropout_10, Pay03Info_embed_output_dropout_10, Pay04Info_embed_output_dropout_10, Pay05Info_embed_output_dropout_10, Pay06Info_embed_output_dropout_10, Pay07Info_embed_output_dropout_10, Pay08Info_embed_output_dropout_10, Pay09Info_embed_output_dropout_10) %>%
    layer_concatenate(name = "pay_mean10") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+15),dim=c(neurons[3]+15,1)),array(starting_values[11,2],dim=c(1))))
  
  payment_mean10 <- list(payment_mean10_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 11
  
  dropout_1_1_applied <- dropout_embed %>%
    dropout_1_1(training = TRUE)
  
  dropout_2_1_applied <- dropout_embed %>%
    dropout_2_1(training = TRUE)
  
  dropout_3_1_applied <- dropout_embed %>%
    dropout_3_1(training = TRUE)
  
  dropout_4_1_applied <- dropout_embed %>%
    dropout_4_1(training = TRUE)
  
  dropout_5_1_applied <- dropout_embed %>%
    dropout_5_1(training = TRUE)
  
  dropout_6_1_applied <- dropout_embed %>%
    dropout_6_1(training = TRUE)
  
  dropout_7_1_applied <- dropout_embed %>%
    dropout_7_1(training = TRUE)
  
  dropout_8_1_applied <- dropout_embed %>%
    dropout_8_1(training = TRUE)
  
  dropout_9_1_applied <- dropout_embed %>%
    dropout_9_1(training = TRUE)
  
  dropout_10_1_applied <- dropout_embed %>%
    dropout_10_1(training = TRUE)
  
  Pay01Info_embed_input_dropout_11 <- list(Pay01Info_embed_input, dropout_10_1_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_11 <- list(Pay01Info_embed_output, dropout_10_1_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_11 <- list(Pay02Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_11 <- list(Pay02Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_11 <- list(Pay03Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_11 <- list(Pay03Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_11 <- list(Pay04Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_11 <- list(Pay04Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_11 <- list(Pay05Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_11 <- list(Pay05Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_11 <- list(Pay06Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_11 <- list(Pay06Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay07Info_embed_input_dropout_11 <- list(Pay07Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay07Info_embed_output_dropout_11 <- list(Pay07Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay08Info_embed_input_dropout_11 <- list(Pay08Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay08Info_embed_output_dropout_11 <- list(Pay08Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay09Info_embed_input_dropout_11 <- list(Pay09Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, dropout_2_1_applied, Time_Known09) %>%
    layer_multiply()
  
  Pay09Info_embed_output_dropout_11 <- list(Pay09Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, dropout_2_1_applied, Time_Known09) %>%
    layer_multiply()
  
  Pay10Info_embed_input_dropout_11 <- list(Pay10Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, dropout_2_1_applied, dropout_1_1_applied, Time_Known10) %>%
    layer_multiply()
  
  Pay10Info_embed_output_dropout_11 <- list(Pay10Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, dropout_2_1_applied, dropout_1_1_applied, Time_Known10) %>%
    layer_multiply()
  
  hidden_11_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_11, Pay02Info_embed_input_dropout_11, Pay03Info_embed_input_dropout_11, Pay04Info_embed_input_dropout_11, Pay05Info_embed_input_dropout_11, Pay06Info_embed_input_dropout_11, Pay07Info_embed_input_dropout_11, Pay08Info_embed_input_dropout_11, Pay09Info_embed_input_dropout_11, Pay10Info_embed_input_dropout_11) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_11 <- list(hidden_11_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator11_pre <- hidden_11 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator11_pre2 <- list(payment_indicator11_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_11, Pay02Info_embed_output_dropout_11, Pay03Info_embed_output_dropout_11, Pay04Info_embed_output_dropout_11, Pay05Info_embed_output_dropout_11, Pay06Info_embed_output_dropout_11, Pay07Info_embed_output_dropout_11, Pay08Info_embed_output_dropout_11, Pay09Info_embed_output_dropout_11, Pay10Info_embed_output_dropout_11) %>%
    layer_concatenate(name = "pay_ind11") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+16),dim=c(neurons[3]+16,1)),array(log(starting_values[12,1]/(1-starting_values[12,1])),dim=c(1))))
  
  payment_indicator11 <- list(payment_indicator11_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean11_pre <- hidden_11 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean11_pre2 <- list(payment_mean11_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_11, Pay02Info_embed_output_dropout_11, Pay03Info_embed_output_dropout_11, Pay04Info_embed_output_dropout_11, Pay05Info_embed_output_dropout_11, Pay06Info_embed_output_dropout_11, Pay07Info_embed_output_dropout_11, Pay08Info_embed_output_dropout_11, Pay09Info_embed_output_dropout_11, Pay10Info_embed_output_dropout_11) %>%
    layer_concatenate(name = "pay_mean11") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+16),dim=c(neurons[3]+16,1)),array(starting_values[12,2],dim=c(1))))
  
  payment_mean11 <- list(payment_mean11_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))  
  
  ### Multiply the outputs with the Time_Predict indicators (0/1)
  
  ### Time 00
  
  payment_indicator00_output <- list(payment_indicator00, Time_Predict_Indicator00) %>%
    layer_multiply(name = 'payment_indicator00_output')
  
  payment_mean00_output <- list(payment_mean00, Time_Predict_Payment00) %>%
    layer_multiply(name = 'payment_mean00_output')
  
  ### Time 01
  
  payment_indicator01_output <- list(payment_indicator01, Time_Predict_Indicator01) %>%
    layer_multiply(name = 'payment_indicator01_output')
  
  payment_mean01_output <- list(payment_mean01, Time_Predict_Payment01) %>%
    layer_multiply(name = 'payment_mean01_output')
  
  ### Time 02
  
  payment_indicator02_output <- list(payment_indicator02, Time_Predict_Indicator02) %>%
    layer_multiply(name = 'payment_indicator02_output')
  
  payment_mean02_output <- list(payment_mean02, Time_Predict_Payment02) %>%
    layer_multiply(name = 'payment_mean02_output')
  
  ### Time 03
  
  payment_indicator03_output <- list(payment_indicator03, Time_Predict_Indicator03) %>%
    layer_multiply(name = 'payment_indicator03_output')
  
  payment_mean03_output <- list(payment_mean03, Time_Predict_Payment03) %>%
    layer_multiply(name = 'payment_mean03_output')
  
  ### Time 04
  
  payment_indicator04_output <- list(payment_indicator04, Time_Predict_Indicator04) %>%
    layer_multiply(name = 'payment_indicator04_output')
  
  payment_mean04_output <- list(payment_mean04, Time_Predict_Payment04) %>%
    layer_multiply(name = 'payment_mean04_output')
  
  ### Time 05
  
  payment_indicator05_output <- list(payment_indicator05, Time_Predict_Indicator05) %>%
    layer_multiply(name = 'payment_indicator05_output')
  
  payment_mean05_output <- list(payment_mean05, Time_Predict_Payment05) %>%
    layer_multiply(name = 'payment_mean05_output')
  
  ### Time 06
  
  payment_indicator06_output <- list(payment_indicator06, Time_Predict_Indicator06) %>%
    layer_multiply(name = 'payment_indicator06_output')
  
  payment_mean06_output <- list(payment_mean06, Time_Predict_Payment06) %>%
    layer_multiply(name = 'payment_mean06_output')
  
  ### Time 07
  
  payment_indicator07_output <- list(payment_indicator07, Time_Predict_Indicator07) %>%
    layer_multiply(name = 'payment_indicator07_output')
  
  payment_mean07_output <- list(payment_mean07, Time_Predict_Payment07) %>%
    layer_multiply(name = 'payment_mean07_output')
  
  ### Time 08
  
  payment_indicator08_output <- list(payment_indicator08, Time_Predict_Indicator08) %>%
    layer_multiply(name = 'payment_indicator08_output')
  
  payment_mean08_output <- list(payment_mean08, Time_Predict_Payment08) %>%
    layer_multiply(name = 'payment_mean08_output')
  
  ### Time 09
  
  payment_indicator09_output <- list(payment_indicator09, Time_Predict_Indicator09) %>%
    layer_multiply(name = 'payment_indicator09_output')
  
  payment_mean09_output <- list(payment_mean09, Time_Predict_Payment09) %>%
    layer_multiply(name = 'payment_mean09_output')
  
  ### Time 10
  
  payment_indicator10_output <- list(payment_indicator10, Time_Predict_Indicator10) %>%
    layer_multiply(name = 'payment_indicator10_output')
  
  payment_mean10_output <- list(payment_mean10, Time_Predict_Payment10) %>%
    layer_multiply(name = 'payment_mean10_output')
  
  ### Time 11
  
  payment_indicator11_output <- list(payment_indicator11, Time_Predict_Indicator11) %>%
    layer_multiply(name = 'payment_indicator11_output')
  
  payment_mean11_output <- list(payment_mean11, Time_Predict_Payment11) %>%
    layer_multiply(name = 'payment_mean11_output')
  
  ### Keras model
  
  model <- keras_model(inputs = c(dropout, cc, AY, AQ, age, inj_part, RepDel,
                                  Time_Known01, Time_Known02, Time_Known03, Time_Known04, Time_Known05, Time_Known06,
                                  Time_Known07, Time_Known08, Time_Known09, Time_Known10, Time_Known11,
                                  Pay00Info, Pay01Info, Pay02Info, Pay03Info, Pay04Info, Pay05Info,
                                  Pay06Info, Pay07Info, Pay08Info, Pay09Info, Pay10Info,
                                  Time_Predict_Indicator00, Time_Predict_Indicator01, Time_Predict_Indicator02, Time_Predict_Indicator03, Time_Predict_Indicator04, Time_Predict_Indicator05,
                                  Time_Predict_Indicator06, Time_Predict_Indicator07, Time_Predict_Indicator08, Time_Predict_Indicator09, Time_Predict_Indicator10, Time_Predict_Indicator11,
                                  Time_Predict_Payment00, Time_Predict_Payment01, Time_Predict_Payment02, Time_Predict_Payment03, Time_Predict_Payment04, Time_Predict_Payment05,
                                  Time_Predict_Payment06, Time_Predict_Payment07, Time_Predict_Payment08, Time_Predict_Payment09, Time_Predict_Payment10, Time_Predict_Payment11),
                       outputs = c(payment_indicator00_output, payment_mean00_output, payment_indicator01_output, payment_mean01_output,
                                   payment_indicator02_output, payment_mean02_output, payment_indicator03_output, payment_mean03_output,
                                   payment_indicator04_output, payment_mean04_output, payment_indicator05_output, payment_mean05_output,
                                   payment_indicator06_output, payment_mean06_output, payment_indicator07_output, payment_mean07_output,
                                   payment_indicator08_output, payment_mean08_output, payment_indicator09_output, payment_mean09_output,
                                   payment_indicator10_output, payment_mean10_output, payment_indicator11_output, payment_mean11_output))
  
  model %>% compile(optimizer = optimizer_nadam(),
                    loss = list(payment_indicator00_output = 'binary_crossentropy', payment_mean00_output = 'mse',
                                payment_indicator01_output = 'binary_crossentropy', payment_mean01_output = 'mse',
                                payment_indicator02_output = 'binary_crossentropy', payment_mean02_output = 'mse',
                                payment_indicator03_output = 'binary_crossentropy', payment_mean03_output = 'mse',
                                payment_indicator04_output = 'binary_crossentropy', payment_mean04_output = 'mse',
                                payment_indicator05_output = 'binary_crossentropy', payment_mean05_output = 'mse',
                                payment_indicator06_output = 'binary_crossentropy', payment_mean06_output = 'mse',
                                payment_indicator07_output = 'binary_crossentropy', payment_mean07_output = 'mse',
                                payment_indicator08_output = 'binary_crossentropy', payment_mean08_output = 'mse',
                                payment_indicator09_output = 'binary_crossentropy', payment_mean09_output = 'mse',
                                payment_indicator10_output = 'binary_crossentropy', payment_mean10_output = 'mse',
                                payment_indicator11_output = 'binary_crossentropy', payment_mean11_output = 'mse'),
                    loss_weights = list(payment_indicator00_output = network_weights[1,1], payment_mean00_output = network_weights[1,2],
                                        payment_indicator01_output = network_weights[2,1], payment_mean01_output = network_weights[2,2],
                                        payment_indicator02_output = network_weights[3,1], payment_mean02_output = network_weights[3,2],
                                        payment_indicator03_output = network_weights[4,1], payment_mean03_output = network_weights[4,2],
                                        payment_indicator04_output = network_weights[5,1], payment_mean04_output = network_weights[5,2],
                                        payment_indicator05_output = network_weights[6,1], payment_mean05_output = network_weights[6,2],
                                        payment_indicator06_output = network_weights[7,1], payment_mean06_output = network_weights[7,2],
                                        payment_indicator07_output = network_weights[8,1], payment_mean07_output = network_weights[8,2],
                                        payment_indicator08_output = network_weights[9,1], payment_mean08_output = network_weights[9,2],
                                        payment_indicator09_output = network_weights[10,1], payment_mean09_output = network_weights[10,2],
                                        payment_indicator10_output = network_weights[11,1], payment_mean10_output = network_weights[11,2],
                                        payment_indicator11_output = network_weights[12,1], payment_mean11_output = network_weights[12,2]))
  model
}


###################################################################################################
### Definition of the function neural_network_fixed_embedding                                   ###
### This function is used to train the neural network (with fixed/pre-trained embedding weights ###
###################################################################################################

### Define the function neural_network_fixed_embedding
### We have the following inputs:
### seed1 = set the seed for reproducibility
### neurons = number of neurons in the hidden layers of the neural network
### dropout_rates = dropout rates for the past payment information
### starting_values = starting values for the neural network parameters
### network_weights = weights of the individual parts of the loss function
neural_network_fixed_embedding <- function(seed1, neurons, dropout_rates, starting_values, network_weights){
  
  ### Seed
  
  use_session_with_seed(seed1)
  
  ### Dropout
  
  dropout_1_1 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_2 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_3 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_4 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_5 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_6 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_7 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_8 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_9 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_1_10 <- layer_dropout(rate = dropout_rates[1]) 
  dropout_2_1 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_2 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_3 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_4 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_5 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_6 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_7 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_8 <- layer_dropout(rate = dropout_rates[2])
  dropout_2_9 <- layer_dropout(rate = dropout_rates[2])
  dropout_3_1 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_2 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_3 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_4 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_5 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_6 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_7 <- layer_dropout(rate = dropout_rates[3])
  dropout_3_8 <- layer_dropout(rate = dropout_rates[3])
  dropout_4_1 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_2 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_3 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_4 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_5 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_6 <- layer_dropout(rate = dropout_rates[4])
  dropout_4_7 <- layer_dropout(rate = dropout_rates[4])
  dropout_5_1 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_2 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_3 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_4 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_5 <- layer_dropout(rate = dropout_rates[5])
  dropout_5_6 <- layer_dropout(rate = dropout_rates[5])
  dropout_6_1 <- layer_dropout(rate = dropout_rates[6])
  dropout_6_2 <- layer_dropout(rate = dropout_rates[6])
  dropout_6_3 <- layer_dropout(rate = dropout_rates[6])
  dropout_6_4 <- layer_dropout(rate = dropout_rates[6])
  dropout_6_5 <- layer_dropout(rate = dropout_rates[6])
  dropout_7_1 <- layer_dropout(rate = dropout_rates[7])
  dropout_7_2 <- layer_dropout(rate = dropout_rates[7])
  dropout_7_3 <- layer_dropout(rate = dropout_rates[7])
  dropout_7_4 <- layer_dropout(rate = dropout_rates[7])
  dropout_8_1 <- layer_dropout(rate = dropout_rates[8])
  dropout_8_2 <- layer_dropout(rate = dropout_rates[8])
  dropout_8_3 <- layer_dropout(rate = dropout_rates[8])
  dropout_9_1 <- layer_dropout(rate = dropout_rates[9])
  dropout_9_2 <- layer_dropout(rate = dropout_rates[9])
  dropout_10_1 <- layer_dropout(rate = dropout_rates[10])
  
  ### Inputs
  
  dropout <- layer_input(shape = c(1), dtype = 'int32', name = 'dropout')
  
  cc <- layer_input(shape = c(1), dtype = 'int32', name = 'cc')
  
  AY <- layer_input(shape = c(1), dtype = 'int32', name = 'AY')
  
  AQ <- layer_input(shape = c(1), dtype = 'int32', name = 'AQ')
  
  age <- layer_input(shape = c(1), dtype = 'int32', name = 'age')
  
  inj_part <- layer_input(shape = c(1), dtype = 'int32', name = 'inj_part')
  
  RepDel <- layer_input(shape = c(1), dtype = 'int32', name = 'RepDel')
  
  Time_Known01 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known01')
  
  Time_Known02 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known02')
  
  Time_Known03 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known03')
  
  Time_Known04 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known04')
  
  Time_Known05 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known05')
  
  Time_Known06 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known06')
  
  Time_Known07 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known07')
  
  Time_Known08 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known08')
  
  Time_Known09 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known09')
  
  Time_Known10 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known10')
  
  Time_Known11 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Known11')
  
  Pay00Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay00Info')
  
  Pay01Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay01Info')
  
  Pay02Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay02Info')
  
  Pay03Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay03Info')
  
  Pay04Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay04Info')
  
  Pay05Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay05Info')
  
  Pay06Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay06Info')
  
  Pay07Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay07Info')
  
  Pay08Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay08Info')
  
  Pay09Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay09Info')
  
  Pay10Info <- layer_input(shape = c(1), dtype = 'int32', name = 'Pay10Info')
  
  Time_Predict_Indicator00 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator00')
  
  Time_Predict_Indicator01 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator01')
  
  Time_Predict_Indicator02 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator02')
  
  Time_Predict_Indicator03 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator03')
  
  Time_Predict_Indicator04 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator04')
  
  Time_Predict_Indicator05 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator05')
  
  Time_Predict_Indicator06 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator06')
  
  Time_Predict_Indicator07 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator07')
  
  Time_Predict_Indicator08 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator08')
  
  Time_Predict_Indicator09 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator09')
  
  Time_Predict_Indicator10 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator10')
  
  Time_Predict_Indicator11 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Indicator11')
  
  Time_Predict_Payment00 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment00')
  
  Time_Predict_Payment01 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment01')
  
  Time_Predict_Payment02 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment02')
  
  Time_Predict_Payment03 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment03')
  
  Time_Predict_Payment04 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment04')
  
  Time_Predict_Payment05 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment05')
  
  Time_Predict_Payment06 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment06')
  
  Time_Predict_Payment07 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment07')
  
  Time_Predict_Payment08 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment08')
  
  Time_Predict_Payment09 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment09')
  
  Time_Predict_Payment10 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment10')
  
  Time_Predict_Payment11 <- layer_input(shape = c(1), dtype = 'float32', name = 'Time_Predict_Payment11')
  
  ### Embeddings
  
  dropout_embed <- dropout %>% 
    layer_embedding(input_dim = 1, output_dim = 1, trainable=FALSE, input_length = 1,
                    weights=list(matrix(c(1)))) %>%
    layer_flatten
  
  cc_embed_input <- cc %>% 
    layer_embedding(input_dim = 51, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  cc_embed_output <- cc %>% 
    layer_embedding(input_dim = 51, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  AY_embed_input <- AY %>% 
    layer_embedding(input_dim = 12, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  AY_embed_output <- AY %>% 
    layer_embedding(input_dim = 12, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  AQ_embed_input <- AQ %>% 
    layer_embedding(input_dim = 4, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  AQ_embed_output <- AQ %>% 
    layer_embedding(input_dim = 4, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  age_embed_input <- age %>% 
    layer_embedding(input_dim = 12, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  age_embed_output <- age %>% 
    layer_embedding(input_dim = 12, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  inj_part_embed_input <- inj_part %>% 
    layer_embedding(input_dim = 46, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  inj_part_embed_output <- inj_part %>% 
    layer_embedding(input_dim = 46, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  RepDel_embed_input <- RepDel %>% 
    layer_embedding(input_dim = 3, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  RepDel_embed_output <- RepDel %>% 
    layer_embedding(input_dim = 3, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay00Info_embed_input <- Pay00Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay00Info_embed_output <- Pay00Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay01Info_embed_input <- Pay01Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay01Info_embed_output <- Pay01Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay02Info_embed_input <- Pay02Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay02Info_embed_output <- Pay02Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay03Info_embed_input <- Pay03Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay03Info_embed_output <- Pay03Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay04Info_embed_input <- Pay04Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay04Info_embed_output <- Pay04Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay05Info_embed_input <- Pay05Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay05Info_embed_output <- Pay05Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay06Info_embed_input <- Pay06Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay06Info_embed_output <- Pay06Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay07Info_embed_input <- Pay07Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay07Info_embed_output <- Pay07Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay08Info_embed_input <- Pay08Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay08Info_embed_output <- Pay08Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay09Info_embed_input <- Pay09Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay09Info_embed_output <- Pay09Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay10Info_embed_input <- Pay10Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  Pay10Info_embed_output <- Pay10Info %>% 
    layer_embedding(input_dim = 6, output_dim = 1, input_length = 1, trainable=FALSE) %>%
    layer_flatten
  
  ### Time 00 - Time 11
  
  features_input <- list(cc_embed_input, AQ_embed_input, age_embed_input, inj_part_embed_input, RepDel_embed_input) %>%
    layer_concatenate
  
  AY_embed_input_NN <- AY_embed_input %>%
    layer_dense(units = neurons[1], activation='linear')
  
  features_output <- list(cc_embed_output, AQ_embed_output, age_embed_output, inj_part_embed_output, RepDel_embed_output) %>%
    layer_concatenate
  
  AY_output_indicator <- AY_embed_output %>%
    layer_dense(units = 1, activation='linear', name="AY_output_indicator",
                weights = list(array(0,dim=c(1,1)),array(0,dim=c(1))))
  
  AY_output_mean <- AY_embed_output %>%
    layer_dense(units = 1, activation='linear', name="AY_output_mean",
                weights = list(array(0,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 00
  
  hidden_0_pre <- features_input %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_0 <- list(hidden_0_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator00_pre <- hidden_0 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator00_pre2 <- list(payment_indicator00_pre, features_output) %>%
    layer_concatenate(name = "pay_ind00") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+5),dim=c(neurons[3]+5,1)),array(log(starting_values[1,1]/(1-starting_values[1,1])),dim=c(1))))
  
  payment_indicator00 <- list(payment_indicator00_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean00_pre <- hidden_0 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean00_pre2 <- list(payment_mean00_pre, features_output) %>%
    layer_concatenate(name = "pay_mean00") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+5),dim=c(neurons[3]+5,1)),array(starting_values[1,2],dim=c(1))))
  
  payment_mean00 <- list(payment_mean00_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 01
  
  hidden_1_pre <- list(features_input, Pay00Info_embed_input) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_1 <- list(hidden_1_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator01_pre <- hidden_1 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator01_pre2 <- list(payment_indicator01_pre, features_output, Pay00Info_embed_output) %>%
    layer_concatenate(name = "pay_ind01") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+6),dim=c(neurons[3]+6,1)),array(log(starting_values[2,1]/(1-starting_values[2,1])),dim=c(1))))
  
  payment_indicator01 <- list(payment_indicator01_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean01_pre <- hidden_1 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean01_pre2 <- list(payment_mean01_pre, features_output, Pay00Info_embed_output) %>%
    layer_concatenate(name = "pay_mean01") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+6),dim=c(neurons[3]+6,1)),array(starting_values[2,2],dim=c(1))))
  
  payment_mean01 <- list(payment_mean01_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 02
  
  dropout_1_10_applied <- dropout_embed %>%
    dropout_1_10(training = TRUE)
  
  Pay01Info_embed_input_dropout_02 <- list(Pay01Info_embed_input, dropout_1_10_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_02 <- list(Pay01Info_embed_output, dropout_1_10_applied, Time_Known01) %>%
    layer_multiply()
  
  hidden_2_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_02) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_2 <- list(hidden_2_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator02_pre <- hidden_2 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator02_pre2 <- list(payment_indicator02_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_02) %>%
    layer_concatenate(name = "pay_ind02") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+7),dim=c(neurons[3]+7,1)),array(log(starting_values[3,1]/(1-starting_values[3,1])),dim=c(1))))
  
  payment_indicator02 <- list(payment_indicator02_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean02_pre <- hidden_2 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean02_pre2 <- list(payment_mean02_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_02) %>%
    layer_concatenate(name = "pay_mean02") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+7),dim=c(neurons[3]+7,1)),array(starting_values[3,2],dim=c(1))))
  
  payment_mean02 <- list(payment_mean02_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 03
  
  dropout_1_9_applied <- dropout_embed %>%
    dropout_1_9(training = TRUE)
  
  dropout_2_9_applied <- dropout_embed %>%
    dropout_2_9(training = TRUE)
  
  Pay01Info_embed_input_dropout_03 <- list(Pay01Info_embed_input, dropout_2_9_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_03 <- list(Pay01Info_embed_output, dropout_2_9_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_03 <- list(Pay02Info_embed_input, dropout_2_9_applied, dropout_1_9_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_03 <- list(Pay02Info_embed_output, dropout_2_9_applied, dropout_1_9_applied, Time_Known02) %>%
    layer_multiply()
  
  hidden_3_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_03, Pay02Info_embed_input_dropout_03) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_3 <- list(hidden_3_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator03_pre <- hidden_3 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator03_pre2 <- list(payment_indicator03_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_03, Pay02Info_embed_output_dropout_03) %>%
    layer_concatenate(name = "pay_ind03") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+8),dim=c(neurons[3]+8,1)),array(log(starting_values[4,1]/(1-starting_values[4,1])),dim=c(1))))
  
  payment_indicator03 <- list(payment_indicator03_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean03_pre <- hidden_3 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean03_pre2 <- list(payment_mean03_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_03, Pay02Info_embed_output_dropout_03) %>%
    layer_concatenate(name = "pay_mean03") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+8),dim=c(neurons[3]+8,1)),array(starting_values[4,2],dim=c(1))))
  
  payment_mean03 <- list(payment_mean03_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 04
  
  dropout_1_8_applied <- dropout_embed %>%
    dropout_1_8(training = TRUE)
  
  dropout_2_8_applied <- dropout_embed %>%
    dropout_2_8(training = TRUE)
  
  dropout_3_8_applied <- dropout_embed %>%
    dropout_3_8(training = TRUE)
  
  Pay01Info_embed_input_dropout_04 <- list(Pay01Info_embed_input, dropout_3_8_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_04 <- list(Pay01Info_embed_output, dropout_3_8_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_04 <- list(Pay02Info_embed_input, dropout_3_8_applied, dropout_2_8_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_04 <- list(Pay02Info_embed_output, dropout_3_8_applied, dropout_2_8_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_04 <- list(Pay03Info_embed_input, dropout_3_8_applied, dropout_2_8_applied, dropout_1_8_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_04 <- list(Pay03Info_embed_output, dropout_3_8_applied, dropout_2_8_applied, dropout_1_8_applied, Time_Known03) %>%
    layer_multiply()
  
  hidden_4_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_04, Pay02Info_embed_input_dropout_04, Pay03Info_embed_input_dropout_04) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_4 <- list(hidden_4_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator04_pre <- hidden_4 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator04_pre2 <- list(payment_indicator04_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_04, Pay02Info_embed_output_dropout_04, Pay03Info_embed_output_dropout_04) %>%
    layer_concatenate(name = "pay_ind04") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+9),dim=c(neurons[3]+9,1)),array(log(starting_values[5,1]/(1-starting_values[5,1])),dim=c(1))))
  
  payment_indicator04 <- list(payment_indicator04_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean04_pre <- hidden_4 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean04_pre2 <- list(payment_mean04_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_04, Pay02Info_embed_output_dropout_04, Pay03Info_embed_output_dropout_04) %>%
    layer_concatenate(name = "pay_mean04") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+9),dim=c(neurons[3]+9,1)),array(starting_values[5,2],dim=c(1))))
  
  payment_mean04 <- list(payment_mean04_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 05
  
  dropout_1_7_applied <- dropout_embed %>%
    dropout_1_7(training = TRUE)
  
  dropout_2_7_applied <- dropout_embed %>%
    dropout_2_7(training = TRUE)
  
  dropout_3_7_applied <- dropout_embed %>%
    dropout_3_7(training = TRUE)
  
  dropout_4_7_applied <- dropout_embed %>%
    dropout_4_7(training = TRUE)
  
  Pay01Info_embed_input_dropout_05 <- list(Pay01Info_embed_input, dropout_4_7_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_05 <- list(Pay01Info_embed_output, dropout_4_7_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_05 <- list(Pay02Info_embed_input, dropout_4_7_applied, dropout_3_7_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_05 <- list(Pay02Info_embed_output, dropout_4_7_applied, dropout_3_7_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_05 <- list(Pay03Info_embed_input, dropout_4_7_applied, dropout_3_7_applied, dropout_2_7_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_05 <- list(Pay03Info_embed_output, dropout_4_7_applied, dropout_3_7_applied, dropout_2_7_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_05 <- list(Pay04Info_embed_input, dropout_4_7_applied, dropout_3_7_applied, dropout_2_7_applied, dropout_1_7_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_05 <- list(Pay04Info_embed_output, dropout_4_7_applied, dropout_3_7_applied, dropout_2_7_applied, dropout_1_7_applied, Time_Known04) %>%
    layer_multiply()
  
  hidden_5_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_05, Pay02Info_embed_input_dropout_05, Pay03Info_embed_input_dropout_05, Pay04Info_embed_input_dropout_05) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_5 <- list(hidden_5_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator05_pre <- hidden_5 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator05_pre2 <- list(payment_indicator05_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_05, Pay02Info_embed_output_dropout_05, Pay03Info_embed_output_dropout_05, Pay04Info_embed_output_dropout_05) %>%
    layer_concatenate(name = "pay_ind05") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+10),dim=c(neurons[3]+10,1)),array(log(starting_values[6,1]/(1-starting_values[6,1])),dim=c(1))))
  
  payment_indicator05 <- list(payment_indicator05_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean05_pre <- hidden_5 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean05_pre2 <- list(payment_mean05_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_05, Pay02Info_embed_output_dropout_05, Pay03Info_embed_output_dropout_05, Pay04Info_embed_output_dropout_05) %>%
    layer_concatenate(name = "pay_mean05") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+10),dim=c(neurons[3]+10,1)),array(starting_values[6,2],dim=c(1))))
  
  payment_mean05 <- list(payment_mean05_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 06
  
  dropout_1_6_applied <- dropout_embed %>%
    dropout_1_6(training = TRUE)
  
  dropout_2_6_applied <- dropout_embed %>%
    dropout_2_6(training = TRUE)
  
  dropout_3_6_applied <- dropout_embed %>%
    dropout_3_6(training = TRUE)
  
  dropout_4_6_applied <- dropout_embed %>%
    dropout_4_6(training = TRUE)
  
  dropout_5_6_applied <- dropout_embed %>%
    dropout_5_6(training = TRUE)
  
  Pay01Info_embed_input_dropout_06 <- list(Pay01Info_embed_input, dropout_5_6_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_06 <- list(Pay01Info_embed_output, dropout_5_6_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_06 <- list(Pay02Info_embed_input, dropout_5_6_applied, dropout_4_6_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_06 <- list(Pay02Info_embed_output, dropout_5_6_applied, dropout_4_6_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_06 <- list(Pay03Info_embed_input, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_06 <- list(Pay03Info_embed_output, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_06 <- list(Pay04Info_embed_input, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, dropout_2_6_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_06 <- list(Pay04Info_embed_output, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, dropout_2_6_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_06 <- list(Pay05Info_embed_input, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, dropout_2_6_applied, dropout_1_6_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_06 <- list(Pay05Info_embed_output, dropout_5_6_applied, dropout_4_6_applied, dropout_3_6_applied, dropout_2_6_applied, dropout_1_6_applied, Time_Known05) %>%
    layer_multiply()
  
  hidden_6_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_06, Pay02Info_embed_input_dropout_06, Pay03Info_embed_input_dropout_06, Pay04Info_embed_input_dropout_06, Pay05Info_embed_input_dropout_06) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_6 <- list(hidden_6_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator06_pre <- hidden_6 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator06_pre2 <- list(payment_indicator06_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_06, Pay02Info_embed_output_dropout_06, Pay03Info_embed_output_dropout_06, Pay04Info_embed_output_dropout_06, Pay05Info_embed_output_dropout_06) %>%
    layer_concatenate(name = "pay_ind06") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+11),dim=c(neurons[3]+11,1)),array(log(starting_values[7,1]/(1-starting_values[7,1])),dim=c(1))))
  
  payment_indicator06 <- list(payment_indicator06_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean06_pre <- hidden_6 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean06_pre2 <- list(payment_mean06_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_06, Pay02Info_embed_output_dropout_06, Pay03Info_embed_output_dropout_06, Pay04Info_embed_output_dropout_06, Pay05Info_embed_output_dropout_06) %>%
    layer_concatenate(name = "pay_mean06") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+11),dim=c(neurons[3]+11,1)),array(starting_values[7,2],dim=c(1))))
  
  payment_mean06 <- list(payment_mean06_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 07
  
  dropout_1_5_applied <- dropout_embed %>%
    dropout_1_5(training = TRUE)
  
  dropout_2_5_applied <- dropout_embed %>%
    dropout_2_5(training = TRUE)
  
  dropout_3_5_applied <- dropout_embed %>%
    dropout_3_5(training = TRUE)
  
  dropout_4_5_applied <- dropout_embed %>%
    dropout_4_5(training = TRUE)
  
  dropout_5_5_applied <- dropout_embed %>%
    dropout_5_5(training = TRUE)
  
  dropout_6_5_applied <- dropout_embed %>%
    dropout_6_5(training = TRUE)
  
  Pay01Info_embed_input_dropout_07 <- list(Pay01Info_embed_input, dropout_6_5_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_07 <- list(Pay01Info_embed_output, dropout_6_5_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_07 <- list(Pay02Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_07 <- list(Pay02Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_07 <- list(Pay03Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_07 <- list(Pay03Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_07 <- list(Pay04Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_07 <- list(Pay04Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_07 <- list(Pay05Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, dropout_2_5_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_07 <- list(Pay05Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, dropout_2_5_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_07 <- list(Pay06Info_embed_input, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, dropout_2_5_applied, dropout_1_5_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_07 <- list(Pay06Info_embed_output, dropout_6_5_applied, dropout_5_5_applied, dropout_4_5_applied, dropout_3_5_applied, dropout_2_5_applied, dropout_1_5_applied, Time_Known06) %>%
    layer_multiply()
  
  hidden_7_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_07, Pay02Info_embed_input_dropout_07, Pay03Info_embed_input_dropout_07, Pay04Info_embed_input_dropout_07, Pay05Info_embed_input_dropout_07, Pay06Info_embed_input_dropout_07) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_7 <- list(hidden_7_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator07_pre <- hidden_7 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator07_pre2 <- list(payment_indicator07_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_07, Pay02Info_embed_output_dropout_07, Pay03Info_embed_output_dropout_07, Pay04Info_embed_output_dropout_07, Pay05Info_embed_output_dropout_07, Pay06Info_embed_output_dropout_07) %>%
    layer_concatenate(name = "pay_ind07") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+12),dim=c(neurons[3]+12,1)),array(log(starting_values[8,1]/(1-starting_values[8,1])),dim=c(1))))
  
  payment_indicator07 <- list(payment_indicator07_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean07_pre <- hidden_7 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean07_pre2 <- list(payment_mean07_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_07, Pay02Info_embed_output_dropout_07, Pay03Info_embed_output_dropout_07, Pay04Info_embed_output_dropout_07, Pay05Info_embed_output_dropout_07, Pay06Info_embed_output_dropout_07) %>%
    layer_concatenate(name = "pay_mean07") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+12),dim=c(neurons[3]+12,1)),array(starting_values[8,2],dim=c(1))))
  
  payment_mean07 <- list(payment_mean07_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 08
  
  dropout_1_4_applied <- dropout_embed %>%
    dropout_1_4(training = TRUE)
  
  dropout_2_4_applied <- dropout_embed %>%
    dropout_2_4(training = TRUE)
  
  dropout_3_4_applied <- dropout_embed %>%
    dropout_3_4(training = TRUE)
  
  dropout_4_4_applied <- dropout_embed %>%
    dropout_4_4(training = TRUE)
  
  dropout_5_4_applied <- dropout_embed %>%
    dropout_5_4(training = TRUE)
  
  dropout_6_4_applied <- dropout_embed %>%
    dropout_6_4(training = TRUE)
  
  dropout_7_4_applied <- dropout_embed %>%
    dropout_7_4(training = TRUE)
  
  Pay01Info_embed_input_dropout_08 <- list(Pay01Info_embed_input, dropout_7_4_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_08 <- list(Pay01Info_embed_output, dropout_7_4_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_08 <- list(Pay02Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_08 <- list(Pay02Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_08 <- list(Pay03Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_08 <- list(Pay03Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_08 <- list(Pay04Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_08 <- list(Pay04Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_08 <- list(Pay05Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_08 <- list(Pay05Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_08 <- list(Pay06Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, dropout_2_4_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_08 <- list(Pay06Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, dropout_2_4_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay07Info_embed_input_dropout_08 <- list(Pay07Info_embed_input, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, dropout_2_4_applied, dropout_1_4_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay07Info_embed_output_dropout_08 <- list(Pay07Info_embed_output, dropout_7_4_applied, dropout_6_4_applied, dropout_5_4_applied, dropout_4_4_applied, dropout_3_4_applied, dropout_2_4_applied, dropout_1_4_applied, Time_Known07) %>%
    layer_multiply()
  
  hidden_8_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_08, Pay02Info_embed_input_dropout_08, Pay03Info_embed_input_dropout_08, Pay04Info_embed_input_dropout_08, Pay05Info_embed_input_dropout_08, Pay06Info_embed_input_dropout_08, Pay07Info_embed_input_dropout_08) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_8 <- list(hidden_8_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator08_pre <- hidden_8 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator08_pre2 <- list(payment_indicator08_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_08, Pay02Info_embed_output_dropout_08, Pay03Info_embed_output_dropout_08, Pay04Info_embed_output_dropout_08, Pay05Info_embed_output_dropout_08, Pay06Info_embed_output_dropout_08, Pay07Info_embed_output_dropout_08) %>%
    layer_concatenate(name = "pay_ind08") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+13),dim=c(neurons[3]+13,1)),array(log(starting_values[9,1]/(1-starting_values[9,1])),dim=c(1))))
  
  payment_indicator08 <- list(payment_indicator08_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean08_pre <- hidden_8 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean08_pre2 <- list(payment_mean08_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_08, Pay02Info_embed_output_dropout_08, Pay03Info_embed_output_dropout_08, Pay04Info_embed_output_dropout_08, Pay05Info_embed_output_dropout_08, Pay06Info_embed_output_dropout_08, Pay07Info_embed_output_dropout_08) %>%
    layer_concatenate(name = "pay_mean08") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+13),dim=c(neurons[3]+13,1)),array(starting_values[9,2],dim=c(1))))
  
  payment_mean08 <- list(payment_mean08_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 09
  
  dropout_1_3_applied <- dropout_embed %>%
    dropout_1_3(training = TRUE)
  
  dropout_2_3_applied <- dropout_embed %>%
    dropout_2_3(training = TRUE)
  
  dropout_3_3_applied <- dropout_embed %>%
    dropout_3_3(training = TRUE)
  
  dropout_4_3_applied <- dropout_embed %>%
    dropout_4_3(training = TRUE)
  
  dropout_5_3_applied <- dropout_embed %>%
    dropout_5_3(training = TRUE)
  
  dropout_6_3_applied <- dropout_embed %>%
    dropout_6_3(training = TRUE)
  
  dropout_7_3_applied <- dropout_embed %>%
    dropout_7_3(training = TRUE)
  
  dropout_8_3_applied <- dropout_embed %>%
    dropout_8_3(training = TRUE)
  
  Pay01Info_embed_input_dropout_09 <- list(Pay01Info_embed_input, dropout_8_3_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_09 <- list(Pay01Info_embed_output, dropout_8_3_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_09 <- list(Pay02Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_09 <- list(Pay02Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_09 <- list(Pay03Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_09 <- list(Pay03Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_09 <- list(Pay04Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_09 <- list(Pay04Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_09 <- list(Pay05Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_09 <- list(Pay05Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_09 <- list(Pay06Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_09 <- list(Pay06Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay07Info_embed_input_dropout_09 <- list(Pay07Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, dropout_2_3_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay07Info_embed_output_dropout_09 <- list(Pay07Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, dropout_2_3_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay08Info_embed_input_dropout_09 <- list(Pay08Info_embed_input, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, dropout_2_3_applied, dropout_1_3_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay08Info_embed_output_dropout_09 <- list(Pay08Info_embed_output, dropout_8_3_applied, dropout_7_3_applied, dropout_6_3_applied, dropout_5_3_applied, dropout_4_3_applied, dropout_3_3_applied, dropout_2_3_applied, dropout_1_3_applied, Time_Known08) %>%
    layer_multiply()
  
  hidden_9_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_09, Pay02Info_embed_input_dropout_09, Pay03Info_embed_input_dropout_09, Pay04Info_embed_input_dropout_09, Pay05Info_embed_input_dropout_09, Pay06Info_embed_input_dropout_09, Pay07Info_embed_input_dropout_09, Pay08Info_embed_input_dropout_09) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_9 <- list(hidden_9_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator09_pre <- hidden_9 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator09_pre2 <- list(payment_indicator09_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_09, Pay02Info_embed_output_dropout_09, Pay03Info_embed_output_dropout_09, Pay04Info_embed_output_dropout_09, Pay05Info_embed_output_dropout_09, Pay06Info_embed_output_dropout_09, Pay07Info_embed_output_dropout_09, Pay08Info_embed_output_dropout_09) %>%
    layer_concatenate(name = "pay_ind09") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+14),dim=c(neurons[3]+14,1)),array(log(starting_values[10,1]/(1-starting_values[10,1])),dim=c(1))))
  
  payment_indicator09 <- list(payment_indicator09_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean09_pre <- hidden_9 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean09_pre2 <- list(payment_mean09_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_09, Pay02Info_embed_output_dropout_09, Pay03Info_embed_output_dropout_09, Pay04Info_embed_output_dropout_09, Pay05Info_embed_output_dropout_09, Pay06Info_embed_output_dropout_09, Pay07Info_embed_output_dropout_09, Pay08Info_embed_output_dropout_09) %>%
    layer_concatenate(name = "pay_mean09") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+14),dim=c(neurons[3]+14,1)),array(starting_values[10,2],dim=c(1))))
  
  payment_mean09 <- list(payment_mean09_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 10
  
  dropout_1_2_applied <- dropout_embed %>%
    dropout_1_2(training = TRUE)
  
  dropout_2_2_applied <- dropout_embed %>%
    dropout_2_2(training = TRUE)
  
  dropout_3_2_applied <- dropout_embed %>%
    dropout_3_2(training = TRUE)
  
  dropout_4_2_applied <- dropout_embed %>%
    dropout_4_2(training = TRUE)
  
  dropout_5_2_applied <- dropout_embed %>%
    dropout_5_2(training = TRUE)
  
  dropout_6_2_applied <- dropout_embed %>%
    dropout_6_2(training = TRUE)
  
  dropout_7_2_applied <- dropout_embed %>%
    dropout_7_2(training = TRUE)
  
  dropout_8_2_applied <- dropout_embed %>%
    dropout_8_2(training = TRUE)
  
  dropout_9_2_applied <- dropout_embed %>%
    dropout_9_2(training = TRUE)
  
  Pay01Info_embed_input_dropout_10 <- list(Pay01Info_embed_input, dropout_9_2_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_10 <- list(Pay01Info_embed_output, dropout_9_2_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_10 <- list(Pay02Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_10 <- list(Pay02Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_10 <- list(Pay03Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_10 <- list(Pay03Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_10 <- list(Pay04Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_10 <- list(Pay04Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_10 <- list(Pay05Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_10 <- list(Pay05Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_10 <- list(Pay06Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_10 <- list(Pay06Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay07Info_embed_input_dropout_10 <- list(Pay07Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay07Info_embed_output_dropout_10 <- list(Pay07Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay08Info_embed_input_dropout_10 <- list(Pay08Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, dropout_2_2_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay08Info_embed_output_dropout_10 <- list(Pay08Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, dropout_2_2_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay09Info_embed_input_dropout_10 <- list(Pay09Info_embed_input, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, dropout_2_2_applied, dropout_1_2_applied, Time_Known09) %>%
    layer_multiply()
  
  Pay09Info_embed_output_dropout_10 <- list(Pay09Info_embed_output, dropout_9_2_applied, dropout_8_2_applied, dropout_7_2_applied, dropout_6_2_applied, dropout_5_2_applied, dropout_4_2_applied, dropout_3_2_applied, dropout_2_2_applied, dropout_1_2_applied, Time_Known09) %>%
    layer_multiply()
  
  hidden_10_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_10, Pay02Info_embed_input_dropout_10, Pay03Info_embed_input_dropout_10, Pay04Info_embed_input_dropout_10, Pay05Info_embed_input_dropout_10, Pay06Info_embed_input_dropout_10, Pay07Info_embed_input_dropout_10, Pay08Info_embed_input_dropout_10, Pay09Info_embed_input_dropout_10) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_10 <- list(hidden_10_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator10_pre <- hidden_10 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator10_pre2 <- list(payment_indicator10_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_10, Pay02Info_embed_output_dropout_10, Pay03Info_embed_output_dropout_10, Pay04Info_embed_output_dropout_10, Pay05Info_embed_output_dropout_10, Pay06Info_embed_output_dropout_10, Pay07Info_embed_output_dropout_10, Pay08Info_embed_output_dropout_10, Pay09Info_embed_output_dropout_10) %>%
    layer_concatenate(name = "pay_ind10") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+15),dim=c(neurons[3]+15,1)),array(log(starting_values[11,1]/(1-starting_values[11,1])),dim=c(1))))
  
  payment_indicator10 <- list(payment_indicator10_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean10_pre <- hidden_10 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean10_pre2 <- list(payment_mean10_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_10, Pay02Info_embed_output_dropout_10, Pay03Info_embed_output_dropout_10, Pay04Info_embed_output_dropout_10, Pay05Info_embed_output_dropout_10, Pay06Info_embed_output_dropout_10, Pay07Info_embed_output_dropout_10, Pay08Info_embed_output_dropout_10, Pay09Info_embed_output_dropout_10) %>%
    layer_concatenate(name = "pay_mean10") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+15),dim=c(neurons[3]+15,1)),array(starting_values[11,2],dim=c(1))))
  
  payment_mean10 <- list(payment_mean10_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  ### Time 11
  
  dropout_1_1_applied <- dropout_embed %>%
    dropout_1_1(training = TRUE)
  
  dropout_2_1_applied <- dropout_embed %>%
    dropout_2_1(training = TRUE)
  
  dropout_3_1_applied <- dropout_embed %>%
    dropout_3_1(training = TRUE)
  
  dropout_4_1_applied <- dropout_embed %>%
    dropout_4_1(training = TRUE)
  
  dropout_5_1_applied <- dropout_embed %>%
    dropout_5_1(training = TRUE)
  
  dropout_6_1_applied <- dropout_embed %>%
    dropout_6_1(training = TRUE)
  
  dropout_7_1_applied <- dropout_embed %>%
    dropout_7_1(training = TRUE)
  
  dropout_8_1_applied <- dropout_embed %>%
    dropout_8_1(training = TRUE)
  
  dropout_9_1_applied <- dropout_embed %>%
    dropout_9_1(training = TRUE)
  
  dropout_10_1_applied <- dropout_embed %>%
    dropout_10_1(training = TRUE)
  
  Pay01Info_embed_input_dropout_11 <- list(Pay01Info_embed_input, dropout_10_1_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay01Info_embed_output_dropout_11 <- list(Pay01Info_embed_output, dropout_10_1_applied, Time_Known01) %>%
    layer_multiply()
  
  Pay02Info_embed_input_dropout_11 <- list(Pay02Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay02Info_embed_output_dropout_11 <- list(Pay02Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, Time_Known02) %>%
    layer_multiply()
  
  Pay03Info_embed_input_dropout_11 <- list(Pay03Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay03Info_embed_output_dropout_11 <- list(Pay03Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, Time_Known03) %>%
    layer_multiply()
  
  Pay04Info_embed_input_dropout_11 <- list(Pay04Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay04Info_embed_output_dropout_11 <- list(Pay04Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, Time_Known04) %>%
    layer_multiply()
  
  Pay05Info_embed_input_dropout_11 <- list(Pay05Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay05Info_embed_output_dropout_11 <- list(Pay05Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, Time_Known05) %>%
    layer_multiply()
  
  Pay06Info_embed_input_dropout_11 <- list(Pay06Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay06Info_embed_output_dropout_11 <- list(Pay06Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, Time_Known06) %>%
    layer_multiply()
  
  Pay07Info_embed_input_dropout_11 <- list(Pay07Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay07Info_embed_output_dropout_11 <- list(Pay07Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, Time_Known07) %>%
    layer_multiply()
  
  Pay08Info_embed_input_dropout_11 <- list(Pay08Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay08Info_embed_output_dropout_11 <- list(Pay08Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, Time_Known08) %>%
    layer_multiply()
  
  Pay09Info_embed_input_dropout_11 <- list(Pay09Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, dropout_2_1_applied, Time_Known09) %>%
    layer_multiply()
  
  Pay09Info_embed_output_dropout_11 <- list(Pay09Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, dropout_2_1_applied, Time_Known09) %>%
    layer_multiply()
  
  Pay10Info_embed_input_dropout_11 <- list(Pay10Info_embed_input, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, dropout_2_1_applied, dropout_1_1_applied, Time_Known10) %>%
    layer_multiply()
  
  Pay10Info_embed_output_dropout_11 <- list(Pay10Info_embed_output, dropout_10_1_applied, dropout_9_1_applied, dropout_8_1_applied, dropout_7_1_applied, dropout_6_1_applied, dropout_5_1_applied, dropout_4_1_applied, dropout_3_1_applied, dropout_2_1_applied, dropout_1_1_applied, Time_Known10) %>%
    layer_multiply()
  
  hidden_11_pre <- list(features_input, Pay00Info_embed_input, Pay01Info_embed_input_dropout_11, Pay02Info_embed_input_dropout_11, Pay03Info_embed_input_dropout_11, Pay04Info_embed_input_dropout_11, Pay05Info_embed_input_dropout_11, Pay06Info_embed_input_dropout_11, Pay07Info_embed_input_dropout_11, Pay08Info_embed_input_dropout_11, Pay09Info_embed_input_dropout_11, Pay10Info_embed_input_dropout_11) %>%
    layer_concatenate() %>%
    layer_dense(units=neurons[1], activation='linear')
  
  hidden_11 <- list(hidden_11_pre, AY_embed_input_NN) %>%
    layer_add %>%
    layer_dense(units=neurons[1], activation='tanh', trainable = FALSE,
                weights = list(diag(1,neurons[1]),array(0,dim=c(neurons[1])))) %>%
    layer_dense(units=neurons[2], activation='tanh')
  
  payment_indicator11_pre <- hidden_11 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_indicator11_pre2 <- list(payment_indicator11_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_11, Pay02Info_embed_output_dropout_11, Pay03Info_embed_output_dropout_11, Pay04Info_embed_output_dropout_11, Pay05Info_embed_output_dropout_11, Pay06Info_embed_output_dropout_11, Pay07Info_embed_output_dropout_11, Pay08Info_embed_output_dropout_11, Pay09Info_embed_output_dropout_11, Pay10Info_embed_output_dropout_11) %>%
    layer_concatenate(name = "pay_ind11") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+16),dim=c(neurons[3]+16,1)),array(log(starting_values[12,1]/(1-starting_values[12,1])),dim=c(1))))
  
  payment_indicator11 <- list(payment_indicator11_pre2, AY_output_indicator) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'sigmoid', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))
  
  payment_mean11_pre <- hidden_11 %>%
    layer_dense(units=neurons[3], activation='tanh')
  
  payment_mean11_pre2 <- list(payment_mean11_pre, features_output, Pay00Info_embed_output, Pay01Info_embed_output_dropout_11, Pay02Info_embed_output_dropout_11, Pay03Info_embed_output_dropout_11, Pay04Info_embed_output_dropout_11, Pay05Info_embed_output_dropout_11, Pay06Info_embed_output_dropout_11, Pay07Info_embed_output_dropout_11, Pay08Info_embed_output_dropout_11, Pay09Info_embed_output_dropout_11, Pay10Info_embed_output_dropout_11) %>%
    layer_concatenate(name = "pay_mean11") %>%
    layer_dense(units = 1, activation='linear',
                weights = list(array(rep(0,neurons[3]+16),dim=c(neurons[3]+16,1)),array(starting_values[12,2],dim=c(1))))
  
  payment_mean11 <- list(payment_mean11_pre2, AY_output_mean) %>%
    layer_add %>%
    layer_dense(units = 1, activation = 'linear', trainable = FALSE,
                weights = list(array(1,dim=c(1,1)),array(0,dim=c(1))))  
  
  ### Multiply the outputs with the Time_Predict indicators (0/1)
  
  ### Time 00
  
  payment_indicator00_output <- list(payment_indicator00, Time_Predict_Indicator00) %>%
    layer_multiply(name = 'payment_indicator00_output')
  
  payment_mean00_output <- list(payment_mean00, Time_Predict_Payment00) %>%
    layer_multiply(name = 'payment_mean00_output')
  
  ### Time 01
  
  payment_indicator01_output <- list(payment_indicator01, Time_Predict_Indicator01) %>%
    layer_multiply(name = 'payment_indicator01_output')
  
  payment_mean01_output <- list(payment_mean01, Time_Predict_Payment01) %>%
    layer_multiply(name = 'payment_mean01_output')
  
  ### Time 02
  
  payment_indicator02_output <- list(payment_indicator02, Time_Predict_Indicator02) %>%
    layer_multiply(name = 'payment_indicator02_output')
  
  payment_mean02_output <- list(payment_mean02, Time_Predict_Payment02) %>%
    layer_multiply(name = 'payment_mean02_output')
  
  ### Time 03
  
  payment_indicator03_output <- list(payment_indicator03, Time_Predict_Indicator03) %>%
    layer_multiply(name = 'payment_indicator03_output')
  
  payment_mean03_output <- list(payment_mean03, Time_Predict_Payment03) %>%
    layer_multiply(name = 'payment_mean03_output')
  
  ### Time 04
  
  payment_indicator04_output <- list(payment_indicator04, Time_Predict_Indicator04) %>%
    layer_multiply(name = 'payment_indicator04_output')
  
  payment_mean04_output <- list(payment_mean04, Time_Predict_Payment04) %>%
    layer_multiply(name = 'payment_mean04_output')
  
  ### Time 05
  
  payment_indicator05_output <- list(payment_indicator05, Time_Predict_Indicator05) %>%
    layer_multiply(name = 'payment_indicator05_output')
  
  payment_mean05_output <- list(payment_mean05, Time_Predict_Payment05) %>%
    layer_multiply(name = 'payment_mean05_output')
  
  ### Time 06
  
  payment_indicator06_output <- list(payment_indicator06, Time_Predict_Indicator06) %>%
    layer_multiply(name = 'payment_indicator06_output')
  
  payment_mean06_output <- list(payment_mean06, Time_Predict_Payment06) %>%
    layer_multiply(name = 'payment_mean06_output')
  
  ### Time 07
  
  payment_indicator07_output <- list(payment_indicator07, Time_Predict_Indicator07) %>%
    layer_multiply(name = 'payment_indicator07_output')
  
  payment_mean07_output <- list(payment_mean07, Time_Predict_Payment07) %>%
    layer_multiply(name = 'payment_mean07_output')
  
  ### Time 08
  
  payment_indicator08_output <- list(payment_indicator08, Time_Predict_Indicator08) %>%
    layer_multiply(name = 'payment_indicator08_output')
  
  payment_mean08_output <- list(payment_mean08, Time_Predict_Payment08) %>%
    layer_multiply(name = 'payment_mean08_output')
  
  ### Time 09
  
  payment_indicator09_output <- list(payment_indicator09, Time_Predict_Indicator09) %>%
    layer_multiply(name = 'payment_indicator09_output')
  
  payment_mean09_output <- list(payment_mean09, Time_Predict_Payment09) %>%
    layer_multiply(name = 'payment_mean09_output')
  
  ### Time 10
  
  payment_indicator10_output <- list(payment_indicator10, Time_Predict_Indicator10) %>%
    layer_multiply(name = 'payment_indicator10_output')
  
  payment_mean10_output <- list(payment_mean10, Time_Predict_Payment10) %>%
    layer_multiply(name = 'payment_mean10_output')
  
  ### Time 11
  
  payment_indicator11_output <- list(payment_indicator11, Time_Predict_Indicator11) %>%
    layer_multiply(name = 'payment_indicator11_output')
  
  payment_mean11_output <- list(payment_mean11, Time_Predict_Payment11) %>%
    layer_multiply(name = 'payment_mean11_output')
  
  ### Keras model
  
  model <- keras_model(inputs = c(dropout, cc, AY, AQ, age, inj_part, RepDel,
                                  Time_Known01, Time_Known02, Time_Known03, Time_Known04, Time_Known05, Time_Known06,
                                  Time_Known07, Time_Known08, Time_Known09, Time_Known10, Time_Known11,
                                  Pay00Info, Pay01Info, Pay02Info, Pay03Info, Pay04Info, Pay05Info,
                                  Pay06Info, Pay07Info, Pay08Info, Pay09Info, Pay10Info,
                                  Time_Predict_Indicator00, Time_Predict_Indicator01, Time_Predict_Indicator02, Time_Predict_Indicator03, Time_Predict_Indicator04, Time_Predict_Indicator05,
                                  Time_Predict_Indicator06, Time_Predict_Indicator07, Time_Predict_Indicator08, Time_Predict_Indicator09, Time_Predict_Indicator10, Time_Predict_Indicator11,
                                  Time_Predict_Payment00, Time_Predict_Payment01, Time_Predict_Payment02, Time_Predict_Payment03, Time_Predict_Payment04, Time_Predict_Payment05,
                                  Time_Predict_Payment06, Time_Predict_Payment07, Time_Predict_Payment08, Time_Predict_Payment09, Time_Predict_Payment10, Time_Predict_Payment11),
                       outputs = c(payment_indicator00_output, payment_mean00_output, payment_indicator01_output, payment_mean01_output,
                                   payment_indicator02_output, payment_mean02_output, payment_indicator03_output, payment_mean03_output,
                                   payment_indicator04_output, payment_mean04_output, payment_indicator05_output, payment_mean05_output,
                                   payment_indicator06_output, payment_mean06_output, payment_indicator07_output, payment_mean07_output,
                                   payment_indicator08_output, payment_mean08_output, payment_indicator09_output, payment_mean09_output,
                                   payment_indicator10_output, payment_mean10_output, payment_indicator11_output, payment_mean11_output))
  
  model %>% compile(optimizer = optimizer_nadam(),
                    loss = list(payment_indicator00_output = 'binary_crossentropy', payment_mean00_output = 'mse',
                                payment_indicator01_output = 'binary_crossentropy', payment_mean01_output = 'mse',
                                payment_indicator02_output = 'binary_crossentropy', payment_mean02_output = 'mse',
                                payment_indicator03_output = 'binary_crossentropy', payment_mean03_output = 'mse',
                                payment_indicator04_output = 'binary_crossentropy', payment_mean04_output = 'mse',
                                payment_indicator05_output = 'binary_crossentropy', payment_mean05_output = 'mse',
                                payment_indicator06_output = 'binary_crossentropy', payment_mean06_output = 'mse',
                                payment_indicator07_output = 'binary_crossentropy', payment_mean07_output = 'mse',
                                payment_indicator08_output = 'binary_crossentropy', payment_mean08_output = 'mse',
                                payment_indicator09_output = 'binary_crossentropy', payment_mean09_output = 'mse',
                                payment_indicator10_output = 'binary_crossentropy', payment_mean10_output = 'mse',
                                payment_indicator11_output = 'binary_crossentropy', payment_mean11_output = 'mse'),
                    loss_weights = list(payment_indicator00_output = network_weights[1,1], payment_mean00_output = network_weights[1,2],
                                        payment_indicator01_output = network_weights[2,1], payment_mean01_output = network_weights[2,2],
                                        payment_indicator02_output = network_weights[3,1], payment_mean02_output = network_weights[3,2],
                                        payment_indicator03_output = network_weights[4,1], payment_mean03_output = network_weights[4,2],
                                        payment_indicator04_output = network_weights[5,1], payment_mean04_output = network_weights[5,2],
                                        payment_indicator05_output = network_weights[6,1], payment_mean05_output = network_weights[6,2],
                                        payment_indicator06_output = network_weights[7,1], payment_mean06_output = network_weights[7,2],
                                        payment_indicator07_output = network_weights[8,1], payment_mean07_output = network_weights[8,2],
                                        payment_indicator08_output = network_weights[9,1], payment_mean08_output = network_weights[9,2],
                                        payment_indicator09_output = network_weights[10,1], payment_mean09_output = network_weights[10,2],
                                        payment_indicator10_output = network_weights[11,1], payment_mean10_output = network_weights[11,2],
                                        payment_indicator11_output = network_weights[12,1], payment_mean11_output = network_weights[12,2]))
  model
}
