#################################
### Recoveries                ###
### Author: Andrea Gabrielli  ###
### Date: 28.05.2020          ###
#################################


#####################################################
### Set working directory to source file location ###
#####################################################

### Session -> Set Working Directory -> To Source File Location


#####################
### Load the data ###
#####################

data_all <- read.table("./Data/data.txt", header=TRUE, sep=";")


##################
### Recoveries ###
##################

recovery_analysis <- data.frame(matrix(ncol = 6, nrow = 4))
rownames(recovery_analysis) <- c("estimated recovery probability","estimated recovery mean","estimated recovery", "true recovery")
colnames(recovery_analysis) <- c("LoB 1", "LoB 2", "LoB 3", "LoB 4", "LoB 5", "LoB 6")
for (LoB in 1:6){
  
  ### Chosen LoB
  data <- data_all[data_all$LoB==LoB,]
  
  ### Calculate and store the true future recovery payments
  recovery_payments <- 0
  for (i in 1:12){
    recovery_payments <- recovery_payments + sum(data[data$AY+data$RepDel>2006-i,8+i][data[data$AY+data$RepDel>2006-i,8+i]<0])
  }
  recovery_analysis[4,LoB] <- round(recovery_payments)
  
  ### Calculate the recovery amounts, the number of recovery payments and the number of claims
  recovery_amounts_table <- array(NA,dim=c(12,12))
  recovery_numbers_table <- array(NA,dim=c(12,12))
  number_of_claims_table <- array(NA,dim=c(12,12))
  for(i in 1:12){
    if (13-i>1){
      for (j in 2:(13-i)){
        recovery_amounts_table[i,j] <- sum(data[data$AY+data$RepDel==1993+i,8+j][data[data$AY+data$RepDel==1993+i,8+j]<0])
        recovery_numbers_table[i,j] <- sum(data[data$AY+data$RepDel==1993+i,8+j]<0)
        number_of_claims_table[i,j] <- length(data[data$AY+data$RepDel==1993+i,8+j])
      }
    }
  }

  ### Calculate and store the estimated estimated recovery
  number_of_claims_vector <- as.numeric(table(data$AY+data$RepDel))
  recovery_analysis[1,LoB] <- sum(colSums(recovery_numbers_table,na.rm=TRUE)*c(0:11))/sum(colSums(number_of_claims_table,na.rm=TRUE)*c(0:11))
  recovery_analysis[2,LoB] <- sum(colSums(recovery_amounts_table,na.rm=TRUE)*c(0:11))/sum(colSums(recovery_numbers_table,na.rm=TRUE)*c(0:11))
  recovery_analysis[3,LoB] <- round(sum((data$AY-1994)*recovery_analysis[1,LoB]*recovery_analysis[2,LoB]))
}

### Store the results
write.table(recovery_analysis, file="./Results/Recoveries/RecoveryEstimates.txt", sep=";", row.names=TRUE, col.names=NA)
