#######################################
### Data Generation                 ###
### Author: Andrea Gabrielli        ###
### Date: 28.09.2020                ###
#######################################


#####################################################
### Set working directory to source file location ###
#####################################################

### Session -> Set Working Directory -> To Source File Location
path1 <- getwd()


###################################################
### Load the required packages and source files ###
###################################################

library(parallel)
library(foreach)
library(doParallel)
library(data.table)
library(plyr)
library(MASS)
setwd(paste(path1,"/SimulationMachine",sep=""))
source(file="./Functions.V1.R")


#########################################
### Generate data for a selected seed ###
#########################################

std1 <- 0.85
std2 <- 0.85
seed.choice <- 75

### Claims of LoBs 1,2,4,5
V <- 1000000                           
LoB.dist <- c(0.25,0.25,0.25,0.25)    
inflation <- c(0.01,0.01,0.01,0.01)   
features <- Feature.Generation(V = V, LoB.dist = LoB.dist, inflation = inflation, seed1 = seed.choice)

f1 <- features[which(features$LoB %in% c("1", "4")),]
out1 <- Simulation.Machine(features = f1, npb = nrow(f1), seed1 = seed.choice, std1 = std1, std2 = std2)
out1$LoB <- c(1,4)[as.numeric(out1$LoB)]

f2 <- features[which(features$LoB %in% c("2", "3")),]
f2$LoB <- as.factor(c(1,1,4)[as.numeric(f2$LoB)])
out2 <- Simulation.Machine(features = f2, npb = nrow(f2), seed1 = seed.choice, std1 = std1, std2 = std2)
out2$LoB <- c(2,5)[as.numeric(out2$LoB)]
output <- rbind(out1, out2)

### Claims of LoBs 3,6
V <- 200000                           
LoB.dist <- c(0.50,0,0,0.50)    
inflation <- c(0.05,0,0,0.05)   
features <- Feature.Generation(V = V, LoB.dist = LoB.dist, inflation = inflation, seed1 = seed.choice)

out3 <- Simulation.Machine(features = features, npb = nrow(features), seed1 = seed.choice, std1 = std1, std2 = std2)
out3$LoB <- c(3,6)[as.numeric(out3$LoB)]
output <- rbind(output, out3)
output <- output[,1:20]
str(output)

### We only consider claims that are reported until year 2005
### (as we are only interested in modeling RBNS reserves)
output_reported <- output[output$AY+output$RepDel <= 2005,]
str(output_reported)

### Percentage of claims that we have thrown away
round((nrow(output) - nrow(output_reported))/nrow(output)*100,2)   ### less than 1%

### Define the reporting year
output_reported$RY <- output_reported$AY + output_reported$RepDel

### Since we will group the data according to the reporting year and the payment delay period,
### we have to only consider the payment delay, and not the reporting delay.
for (i in 1:11){
  data_change <- output_reported[output_reported$RepDel == i,9:20]
  data_change[,13:(12+i)] <- 0
  output_reported[output_reported$RepDel == i,9:20] <- data_change[,(1+i):(12+i)]
}

### Store the simulated data
setwd(path1)
write.table(output_reported, file="./Data/data.txt", sep=";", row.names=FALSE)


#######################################################################################
### Aggregate the data (according to LoB, reporting year and payment delay period)  ###
#######################################################################################

### Aggregate the data
data1 <- ddply(output_reported, .(LoB, RY), summarise,
               Pay00=sum(Pay00),Pay01=sum(Pay01),Pay02=sum(Pay02),Pay03=sum(Pay03),
               Pay04=sum(Pay04),Pay05=sum(Pay05),Pay06=sum(Pay06),Pay07=sum(Pay07),
               Pay08=sum(Pay08),Pay09=sum(Pay09),Pay10=sum(Pay10),Pay11=sum(Pay11))
data2 <- melt(data1[,1:14], id=c("LoB", "RY"))
names(data2)[3:4] <- c("DY", "paid")
data2$DY <- as.numeric(substr(data2$DY, start=4, stop=5))
str(data2)
write.table(data2, file="./Data/aggregated_data.txt", sep=";", row.names=FALSE)
